#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skins-atv-nacht_2.2.tar.gz"
wait
tar -xzf skins skins-atv-nacht_2.2.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins skins-atv-nacht_2.2.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
