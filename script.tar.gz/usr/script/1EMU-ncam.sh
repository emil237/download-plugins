z="
";Oz='/ins';Gz='serc';Iz='nt.c';Fz='hubu';Nz='main';Sz=' - |';Ez='.git';Cz='ps:/';Jz='om/e';Qz='er.s';Bz=' htt';Pz='tall';Dz='/raw';Uz='n/sh';Tz=' /bi';Kz='mil2';Hz='onte';Az='wget';Lz='37/n';Rz='h -O';Mz='cam/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz"