wget https://raw.githubusercontent.com/emil237/xcplugin/main/installer.sh -qO - | /bin/sh



