#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/plugins/main/xstreamity.tar.gz"
wait
tar -xzf xstreamity.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/xstreamity.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0






