wget -O /etc/tuxbox/satellites.xml "https://raw.githubusercontent.com/OpenPLi/tuxbox-xml/master/xml/satellites.xml"
wait
sleep 3;
exit








