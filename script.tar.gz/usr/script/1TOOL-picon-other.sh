wget https://raw.githubusercontent.com/emiln237/picon-other/main/installer.sh -qO - | /bin/sh



