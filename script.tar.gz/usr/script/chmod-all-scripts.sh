#!/bin/sh
#

echo " CHMOD All SCRIPTS "

chmod 755 /usr/script/*.sh
wait
exit







