
#!/bin/sh
#

wget -O /var/volatile/tmp/Skin-BLACK-NEON-FHD-S-By-Muaath.ipk "https://raw.githubusercontent.com/emil237/skins-openatv/main/Skin-BLACK-NEON-FHD-S-By-Muaath.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/Skin-BLACK-NEON-FHD-S-By-Muaath.ipk
wait
sleep 2;
exit 0
























