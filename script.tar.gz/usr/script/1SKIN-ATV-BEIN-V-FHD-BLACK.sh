#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/SKIN-BEIN-V-FHD-BLACK.tar.gz"
wait
tar -xzf SKIN-BEIN-V-FHD-BLACK.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/SKIN-BEIN-V-FHD-BLACK.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0





























