#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skins-army-touch-fhd-atv-py3_1.2-r2.tar.gz"
wait
tar -xzf skins-army-touch-fhd-atv-py3_1.2-r2.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-army-touch-fhd-atv-py3_1.2-r2.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


