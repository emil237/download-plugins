#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/skin-redglassmacos-bymikae.tar.gz"
wait
tar -xzf skin-redglassmacos-bymikae.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skin-redglassmacos-bymikae.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


