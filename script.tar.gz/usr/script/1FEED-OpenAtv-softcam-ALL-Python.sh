opkg install --force-overwrite  http://178.63.156.75/paneladdons/Feeds/OpenAtv/softcam-feed-universal_4.5-r0_all.ipk
wait
sleep 2;
exit 0





