wget https://raw.githubusercontent.com/emil237/feeds-finder/main/installer.sh -O - | /bin/sh


