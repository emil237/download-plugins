
#!/bin/sh
#

wget -O /var/volatile/tmp/service-scan-updates_1.1_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/service-scan-updates_1.1_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/service-scan-updates_1.1_all.ipk
wait
sleep 2;
exit 0








