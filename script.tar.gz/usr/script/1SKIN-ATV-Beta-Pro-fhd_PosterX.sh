#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/skin-beta-pro-fhd_v1.5_PosterX_By_Bahaa.tar.gz"
wait
tar -xzf skin-beta-pro-fhd_v1.5_PosterX_By_Bahaa.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skin-beta-pro-fhd_v1.5_PosterX_By_Bahaa.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0





























