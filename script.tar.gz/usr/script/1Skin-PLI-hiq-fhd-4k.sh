#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skin-pli-hiq-fhd-4k.tar.gz"
wait
tar -xzf skin-pli-hiq-fhd-4k.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skin-pli-hiq-fhd-4k.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
