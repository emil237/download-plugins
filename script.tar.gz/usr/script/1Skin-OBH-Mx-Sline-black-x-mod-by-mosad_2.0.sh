#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-obh/main/skins-obh-mx-sline-black-x-mod-by-mosad_2.0.tar.gz"
wait
tar -xzf skins-obh-mx-sline-black-x-mod-by-mosad_2.0.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-obh-mx-sline-black-x-mod-by-mosad_2.0.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0

































