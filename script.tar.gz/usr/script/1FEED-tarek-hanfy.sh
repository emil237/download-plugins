wait
wget -O /etc/opkg/settingsz.conf https://raw.githubusercontent.com/tarekzoka/settingsz/main/feed/settingsz.conf
wait
opkg update
wait
sleep 2;
exit 0





