#!/bin/sh
# 
##script install skin-Novaler-S-Xtra-FHD## 
sleep 1
wget -q https://raw.githubusercontent.com/emil237/skins-openatv/main/skin-Novaler-S-Xtra-FHD.tar.gz -P /tmp
echo "Downloading the Skin Novaler-S-Xtra-FHD ..."
sleep 1
rm -rf /usr/share/enigma2/skin-Novaler-S-Xtra-FHD
echo "old version is removed..."
sleep 1
if [ -f /tmp/skin-Novaler-S-Xtra-FHD.tar.gz ]; then
	tar -xzf /tmp/skin-Novaler-S-Xtra-FHD.tar.gz -C /
fi
sleep 1
rm -rf /tmp/skin-Novaler-S-Xtra-FHD.tar.gz
echo " SKINS Installed..."
sleep 1
exit 0
