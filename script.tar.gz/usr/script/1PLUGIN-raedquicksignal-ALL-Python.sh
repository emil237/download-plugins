wget https://raw.githubusercontent.com/emil237/RaedQuickSignal/main/installer.sh -O - | /bin/sh
