wget http://tunisia-dreambox.info/TSplugins/RaedQuickSignal/installer.sh -O - | /bin/sh



