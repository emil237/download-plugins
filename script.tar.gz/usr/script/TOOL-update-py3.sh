opkg update && opkg upgrade
   opkg install p7zip
   opkg install wget 
   opkg install curl  
   opkg install python3-lxml 
   opkg install python3-requests  
   opkg install python3-beautifulsoup4   
   opkg install python3-cfscrape 
   opkg install livestreamersrv 
   opkg install python3-six 
   opkg install python3-sqlite3 
   opkg install python3-pycrypto 
   opkg install f4mdump python3-image  
   opkg install python3-imaging  
   opkg install python3-argparse 
   opkg install python3-multiprocessing
   opkg install python3-mmap 
   opkg install python3-ndg-httpsclient  
   opkg install python3-pydoc 
   opkg install python3-xmlrpc
   opkg install python3-certifi 
   opkg install python3-urllib3 
   opkg install python3-chardet
   opkg install python3-pysocks 
   opkg install python3-js2py 
   opkg install python3-pillow
   opkg update
   opkg install enigma2-plugin-systemplugins-serviceapp
   opkg install ffmpeg
   opkg install exteplayer3
   opkg install gstplayer
   opkg update
   opkg install gstreamer1.0-plugins-good
   opkg install gstreamer1.0-plugins-ugly
   opkg install gstreamer1.0-plugins-base
   opkg install gstreamer1.0-plugins-bad
wait
echo ". >>>>         RESTARING     <<<<"
echo ""
init 4
sleep 2
init 3
exit 0
























