opkg install --force-overwrite
https://raw.githubusercontent.com/emil237/plugins/main/netspeedtest_1.0_all.ipk
wait
sleep 2;
exit 0



































