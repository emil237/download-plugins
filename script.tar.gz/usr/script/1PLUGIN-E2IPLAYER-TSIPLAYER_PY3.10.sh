wget -q "--no-check-certificate" http://ipkinstall.ath.cx/ipk-install/E2IPLAYER_TSiplayer-PYTHON3.10/e2iplayer-py310.sh -O - | /bin/sh


