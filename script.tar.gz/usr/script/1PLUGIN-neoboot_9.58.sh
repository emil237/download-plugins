wget https://raw.githubusercontent.com/emilnabil/neoboot_v9.58/main/iNB.sh -O - | /bin/sh


