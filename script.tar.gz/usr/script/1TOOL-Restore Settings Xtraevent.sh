#!/bin/sh
echo "Restore Settings Xtraevent"
sleep 1
WORD='xtraEvent'; BACKUP='/hdd/xtraEvent_Backup/settings_backup_xtraEvent'; SETF='/etc/enigma2/settings'; TF='/tmp/tmpFile'; grep -v $WORD $SETF > $TF && cat $BACKUP >> $TF && init 4 && sleep 3 && mv -f $TF $SETF && init 3

exit




