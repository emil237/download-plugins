#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/Skin-TOKYO2020-FHD.tar.gz"
wait
tar -xzf Skin-TOKYO2020-FHD.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/Skin-TOKYO2020-FHD.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


