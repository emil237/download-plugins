
#!/bin/sh
#

wget -O /var/volatile/tmp/skins-SilverHarmony_SE-Mod_Borsalino_OpenPLi7_all.ipk "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/skins-SilverHarmony_SE-Mod_Borsalino_OpenPLi7_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/skins-SilverHarmony_SE-Mod_Borsalino_OpenPLi7_all.ipk
wait
sleep 2;
exit 0
























