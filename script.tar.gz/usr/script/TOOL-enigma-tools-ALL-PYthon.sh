wget https://raw.githubusercontent.com/emilnabil/Enigma-Update/main/update-enigma.sh -O - | /bin/sh
