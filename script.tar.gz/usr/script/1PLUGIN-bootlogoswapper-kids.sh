#!/bin/sh
#

cd /tmp
rm -rf * > /dev/null 2>&1
cd ..
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwapper

###########################
wget -O /var/volatile/tmp/bootlogoswapper-Kids_v2.4_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/bootlogoswapper-Kids_v2.4_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/bootlogoswapper-Kids_v2.4_all.ipk
wait
echo">>>>>>UPLOADED BY EMIL_NABIL <<<<<<<"
sleep 4;
wait
killall -9 enigma2
exit 0











           
