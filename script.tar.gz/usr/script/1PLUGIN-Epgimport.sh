wget https://raw.githubusercontent.com/emil237/epgimport/main/installer.sh -O - | /bin/sh










