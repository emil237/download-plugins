#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skins-pli-multiposter-fhd_v1.6.tar.gz"
wait
tar -xzf skins-pli-multiposter-fhd_v1.6.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-pli-multiposter-fhd_v1.6.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
