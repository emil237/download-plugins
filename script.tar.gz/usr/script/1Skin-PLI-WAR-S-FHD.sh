#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-openpli/main/Skin-WAR-S-FHD.tar.gz"
wait
tar -xzf Skin-WAR-S-FHD.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/Skin-WAR-S-FHD.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0



























