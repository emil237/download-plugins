wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/chocholousek-picons/main/installer.sh -O - | /bin/sh

