#!/bin/sh
echo "Installing Plugin dreamsat Panel-py_3.10 "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/DreamSat-Panel_py-3.10.tar.gz" > /tmp/DreamSat-Panel_py-3.10.tar.gz
sleep 1
echo "install Plugin dreamsat panel...."
cd /tmp
tar -xzf DreamSat-Panel_py-3.10.tar.gz  -C /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm /tmp/DreamSat-Panel_py-3.10.tar.gz
sleep 2
killall -9 enigma2
exit











