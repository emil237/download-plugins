#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv/main/skins-atv-novaler-s-xtra-fhd-v2.1.tar.gz"
wait
tar -xzf skins-atv-novaler-s-xtra-fhd-v2.1.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-atv-novaler-s-xtra-fhd-v2.1.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
