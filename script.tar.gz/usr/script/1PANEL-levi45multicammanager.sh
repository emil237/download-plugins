wget https://raw.githubusercontent.com/emil237/levi45multicammanager/main/installer.sh -O - | /bin/sh




