#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/OP-ARTKOALA-icon-mini_tv-by-Ahmed-Riad.tar.gz"
wait
tar -xzf OP-ARTKOALA-icon-mini_tv-by-Ahmed-Riad.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/OP-ARTKOALA-icon-mini_tv-by-Ahmed-Riad.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0



























