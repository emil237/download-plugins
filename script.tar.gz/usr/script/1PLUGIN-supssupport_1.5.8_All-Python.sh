wget https://raw.githubusercontent.com/emil237/SubsSupport/main/installer.sh -O - | /bin/sh


