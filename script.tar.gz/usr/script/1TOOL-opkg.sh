opkg install --force-overwrite  https://raw.githubusercontent.com/emil237/plugins/main/opkg-tools_all.ipk
wait
sleep 2;
exit 0







