#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv/main/skins-atv-bluemetal-fhd-v2.08.tar.gz"
wait
tar -xzf skins-atv-bluemetal-fhd-v2.08.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-atv-bluemetal-fhd-v2.08.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
