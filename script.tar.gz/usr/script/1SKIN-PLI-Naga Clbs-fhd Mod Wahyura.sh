#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/SKIN-PLI-Naga Clbs-fhd Mod Wahyura.tar.gz"
wait
tar -xzf SKIN-PLI-Naga Clbs-fhd Mod Wahyura.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/SKIN-PLI-Naga Clbs-fhd Mod Wahyura.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


