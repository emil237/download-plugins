#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skin.PY3-BlackX.FHD-V1.0.tar.gz"
wait
tar -xzf skin.PY3-BlackX.FHD-V1.0.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skin.PY3-BlackX.FHD-V1.0.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0






























