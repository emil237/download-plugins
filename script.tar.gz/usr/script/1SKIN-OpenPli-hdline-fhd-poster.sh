#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/skins-OpenPli/main/skins-hdline-fhd-super-mod_1.2-poster_all.tar.gz"
wait
tar -xzf skins-hdline-fhd-super-mod_1.2-poster_all.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-hdline-fhd-super-mod_1.2-poster_all.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
exit 0



















