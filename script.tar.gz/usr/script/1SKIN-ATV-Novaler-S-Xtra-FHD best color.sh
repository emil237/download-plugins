wget https://raw.githubusercontent.com/emilnabil/skin-novaler-xtra/main/installer.sh -qO - | /bin/sh

