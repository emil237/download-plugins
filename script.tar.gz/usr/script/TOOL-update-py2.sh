opkg update && opkg upgrade
   opkg update
   opkg install 
   opkg install wget 
   opkg install curl  
   opkg install hlsdl 
   opkg install python-lxml 
   opkg install python-requests 
   opkg install python-beautifulsoup4 
   opkg install python-cfscrape 
   opkg install livestreamer 
   opkg install vlivestreamersrv 
   opkg install python-six 
   opkg install python-sqlite3 
   opkg install python-pycrypto 
   opkg install f4mdump 
   opkg install python-image 
   opkg install python-imaging 
   opkg install python-argparse 
   opkg install python-multiprocessing 
   opkg install python-mmap 
   opkg install python-ndg-httpsclient 
   opkg install python-pydoc python-xmlrpc 
   opkg install python-certifi 
   opkg install python-urllib3 
   opkg install python-chardet 
   opkg install python-pysocks
   opkg install enigma2-plugin-systemplugins-serviceapp
    opkg install ffmpeg
    opkg install exteplayer3
    opkg install gstplayer
    opkg update
    opkg install gstreamer1.0-plugins-good
    opkg install gstreamer1.0-plugins-ugly
    opkg install gstreamer1.0-plugins-base
    opkg install gstreamer1.0-plugins-bad
wait
echo ". >>>>         RESTARING     <<<<"
echo ""
init 4
sleep 2
init 3
exit 0
