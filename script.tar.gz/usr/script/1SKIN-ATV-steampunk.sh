#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/skins-openatv/main/skins-steampunk_1.3.tar.gz"
wait
tar xzvpf /tmp/*.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-steampunk_1.3.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0


