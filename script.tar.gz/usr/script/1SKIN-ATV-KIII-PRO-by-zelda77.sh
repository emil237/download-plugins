#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/skins-KIII-PRO-by-zelda77_v3.3_all.tar.gz"
wait
tar -xzf skins-KIII-PRO-by-zelda77_v3.3_all.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-KIII-PRO-by-zelda77_v3.3_all.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


























