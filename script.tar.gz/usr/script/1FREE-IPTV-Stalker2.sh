z="
";Zz='.con';Kz='gith';Nz='nten';Vz='mag/';az='f"';Mz='erco';Yz='lker';Dz='e/st';Tz='rtal';Fz='r.co';Wz='main';Az='wget';Jz='raw.';Rz='ATPR';Sz='O/Po';Hz='http';Xz='/sta';Bz=' -O ';Lz='ubus';bz='exit';Qz='rimS';cz=' 0';Uz='-100';Gz='nf "';Oz='t.co';Cz='/hom';Iz='s://';Pz='m/ka';Ez='alke';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$z$bz$cz"