#!/bin/sh
echo "Uninstall"
sleep 1
init 4
chattr -i /usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/plugin.*
rm -rf /usr/lib/enigma2/python/Plugins/Extensions/NeoBoot/
chattr -i /usr/lib/periodon/*.*
rm -rf /usr/lib/periodon/
chattr -i /usr/lib/enigma2/python/Tools/Testinout.*
rm -rf /usr/lib/enigma2/python/Tools/Testinout.*
opkg remove enigma2-plugin-extensions-neoboot
echo "OK"
sleep 3;
reboot

exit


