#!/bin/sh
#
ln -s /media/hdd/picon /usr/share/enigma2
exit



