wget -q "--no-check-certificate" https://raw.githubusercontent.com/emilnabil/emil-vip-feed/main/1FEED-emil-feed.sh -O - | /bin/sh

