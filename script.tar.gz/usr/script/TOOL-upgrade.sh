init 4 && opkg update && opkg upgrade && init 6

