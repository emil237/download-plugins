opkg install https://raw.githubusercontent.com/emil237/plugins/main/XtreamTV_0.2.3_armv7a.ipk
wait
sleep 2;
exit 0

























