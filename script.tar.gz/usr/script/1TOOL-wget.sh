opkg install wget
