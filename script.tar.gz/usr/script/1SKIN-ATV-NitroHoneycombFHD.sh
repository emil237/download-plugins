
#!/bin/sh
#

wget -O /var/volatile/tmp/skin.NitroHoney_all.ipk "https://raw.githubusercontent.com/emil237/skins-openatv/main/skin.NitroHoney_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -r /var/volatile/tmp/skin.NitroHoney_all.ipk
wait
sleep 2;
exit 0








