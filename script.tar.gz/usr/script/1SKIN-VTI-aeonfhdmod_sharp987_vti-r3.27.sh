#!/bin/sh
sleep 1
echo "Install SKINS"
echo ""
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/abo-barby/skins-vti/main/skin-aeonfhdmod_sharp987_vti-r3.27.tar.gz" > /tmp/skin-aeonfhdmod_sharp987_vti-r3.27.tar.gz
sleep 1
echo "installing ...."
cd /tmp
tar -xzf skin-aeonfhdmod_sharp987_vti-r3.27.tar.gz  -C /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
cd 
rm -f /tmp/skin-aeonfhdmod_sharp987_vti-r3.27.tar.gz
echo "OK"
killall -9 enigma2
exit









