#!/bin/bash
# ###############################################
echo "d2dldCBodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vZW1pbDIzNy9uZW9ib290X3Y5LjY1L21haW4vaU5CLnNoIC1PIC0gfCAvYmluL3No" | base64 -d | sh



