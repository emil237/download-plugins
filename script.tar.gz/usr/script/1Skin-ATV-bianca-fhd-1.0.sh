#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv/main/skins-atv-bianca-fhd-1.0.tar.gz"
wait
tar -xzf skins-atv-bianca-fhd-1.0.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-atv-bianca-fhd-1.0.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
