#!/bin/sh
#

rm -rf /etc/enigma2/lamedb
rm -rf /etc/enigma2/lamedb5
rm -rf /etc/enigma2/*list
rm -rf /etc/enigma2/*.tv
rm -rf /etc/enigma2/*.radio
wait
sleep 2;
exit




