#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/skins-madmax-impossible_1.6_pli.tar.gz"
wait
tar -xzf skins-madmax-impossible_1.6_pli.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-madmax-impossible_1.6_pli.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0


