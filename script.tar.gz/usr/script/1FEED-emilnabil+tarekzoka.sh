#!/bin/sh
#
#
wget -O /etc/opkg/emil-vip-feed.conf https://raw.githubusercontent.com/emilnabil/feed-emil/main/emil-vip-feed.conf
wait
wget -O /etc/opkg/user-feed.conf https://raw.githubusercontent.com/tarekzoka/settingsz/main/user-feed.conf
opkg update
wait
sleep 2;
exit 0








