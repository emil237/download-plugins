#!/bin/sh
#
#
wget -O /etc/opkg/user-feed.conf https://raw.githubusercontent.com/emilnabil/feed-emil/main/user-feed.conf
wait
wget -O /etc/opkg/settingsz.conf https://raw.githubusercontent.com/tarekzoka/settingsz/main/feed/settingsz.conf
opkg update
wait
sleep 2;
exit 0







