#!/bin/sh
sleep 1
echo "Install SKINS"
echo ""
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/abo-barby/skins-vti/main/skin-full-hd_9.7.tar.gz" > /tmp/skin-full-hd_9.7.tar.gz
sleep 1
echo "installing ...."
cd /tmp
tar -xzf skin-full-hd_9.7.tar.gz  -C /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
cd 
rm -f /tmp/skin-full-hd_9.7.tar.gz
echo "OK"
echo " UPLOADED BY EMIL_NABIL
sleep 4;
echo ""
echo ""
exit











