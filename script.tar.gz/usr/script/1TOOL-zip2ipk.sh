wget http://tunisia-dreambox.info/TSplugins/zip2ipk_plugin/installer.sh -O - | /bin/sh

