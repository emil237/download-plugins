#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/SKIN-QATAR-2022-V-FHD.tar.gz"
wait
tar -xzf SKIN-QATAR-2022-V-FHD.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/SKIN-QATAR-2022-V-FHD.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0

