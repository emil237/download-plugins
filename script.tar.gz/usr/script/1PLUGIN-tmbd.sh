
#!/bin/sh
#

wget -O /var/volatile/tmp/tmbd_8.6_all.ipk "https://raw.githubusercontent.com/emil237/plugins/main/tmbd_8.6_all.ipk"
wait
opkg install --force-overwrite /tmp/*.ipk
wait
rm -f /var/volatile/tmp/tmbd_8.6_all.ipk
wait
sleep 2;
exit 0
































