opkg install ffmpeg exteplayer3 enigma2-plugin-systemplugins-serviceapp
wait
sleep 2;
exit 0
