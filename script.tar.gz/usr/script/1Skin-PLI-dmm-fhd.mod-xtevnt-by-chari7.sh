#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/abo-barby/skins-atv-pli/main/skins-dmm-fhd.mod-xtevnt-by-chari7.tar.gz"
wait
tar -xzf skins-dmm-fhd.mod-xtevnt-by-chari7.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-dmm-fhd.mod-xtevnt-by-chari7.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0
