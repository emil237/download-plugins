wget -q "--no-check-certificate" http://plugin.gosatplus.com/Plugin/R2/OPENPLI/mips-openpli-r2-installer.sh -O - | /bin/sh

