wget -q "--no-check-certificate" https://gitlab.com/emilnabil1/teamnitro/-/raw/main/installer.sh -O - | /bin/sh


