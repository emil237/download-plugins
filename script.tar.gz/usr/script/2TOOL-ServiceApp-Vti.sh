#!/bin/sh
sleep 1
echo "Install ServiceApp For Vti"
echo ""
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/abo-barby/plugins/main/ServiceApp-Vti.tar.gz" > /tmp/ServiceApp-Vti.tar.gz
sleep 1
echo "installing ...."
cd /tmp
tar -xzf ServiceApp-Vti.tar.gz  -C /
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
cd 
rm -f /tmp/ServiceApp-Vti.tar.gz
echo "OK"
echo " UPLOADED BY EMIL_NABIL
sleep 4;
echo ""
echo ""
exit




















