wget https://raw.githubusercontent.com/emil237/oscam/main/installer.sh -O - | /bin/sh




