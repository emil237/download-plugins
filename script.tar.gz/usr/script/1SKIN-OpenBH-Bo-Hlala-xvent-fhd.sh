wget https://raw.githubusercontent.com/emilnabil/SKIN-BOHILALA-OBH/main/installer.sh -qO - | /bin/sh

