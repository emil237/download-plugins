wget https://raw.githubusercontent.com/emil237/ansite/main/installer.sh -qO - | /bin/sh


