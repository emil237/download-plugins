#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/download-plugins/main/suptv.tar.gz"
wait
tar -xzf suptv.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/suptv.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0










