wget -O /etc/tuxbox/config/SoftCam.Key http://drive.google.com/uc?authuser=0&id=1aujij43w7qAyPHhfBLAN9sE-BZp8_AwI&export=download

