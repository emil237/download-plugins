#!/bin/sh
 # 
# script download my scripts #  
cd /tmp
set -e 
curl  -k -Lbk -m 55532 -m 555104 "https://drive.google.com/uc?id=15QFJYCKYSfyBKdOayXexatWYx1N31gaV&export=download" > /tmp/script.tar.gz
sleep 1
wait
tar -xzf script.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/script.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0




