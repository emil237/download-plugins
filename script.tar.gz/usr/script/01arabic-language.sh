z="
";Xz='sh';Hz='onte';Dz='/raw';Lz='37/a';Fz='hubu';Iz='nt.c';Gz='serc';Ez='.git';Sz='ller';Rz='nsta';Az='wget';Pz='e/ma';Vz=' | /';Oz='guag';Bz=' htt';Kz='mil2';Cz='ps:/';Uz='-O -';Jz='om/e';Mz='rabi';Nz='clan';Tz='.sh ';Wz='bin/';Qz='in/i';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"