wget http://tunisia-dreambox.info/TSplugins/m3uPlayer/installer.sh -O - | /bin/sh

