#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-obh/-/raw/main/skins-mx-sline-all-obh.tar.gz"
wait
tar -xzf skins-mx-sline-all-obh.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-mx-sline-all-obh.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0

