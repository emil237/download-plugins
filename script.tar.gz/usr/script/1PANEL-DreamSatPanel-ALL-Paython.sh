#!/bin/sh
#
echo "d2dldCAtcSAiLS1uby1jaGVjay1jZXJ0aWZpY2F0ZSIgaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2VtaWwyMzcvZHJlYW1zYXQvbWFpbi9pbnN0YWxsZXIuc2ggLU8gLSB8IC9iaW4vc2g=
" | base64 -d | sh



