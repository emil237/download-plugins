wget -O /etc/tuxbox/config/SoftCam.Key http://raw.githubusercontent.com/audi06/SoftCam.Key_Serjoga/master/SoftCam.Key

