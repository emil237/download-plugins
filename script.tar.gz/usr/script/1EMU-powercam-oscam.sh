#!/bin/sh
echo "Installing Emu Softcams "
sleep 1
cd /tmp
curl  -k -Lbk -m 55532 -m 555104 "https://raw.githubusercontent.com/emil237/download-plugins/main/softcams-powercam-oscam_11715-emu-r798_all.ipk" > /tmp/softcams-powercam-oscam_11715-emu-r798_all.ipk
sleep 1
echo "install Emu powercam-oscam ...."
cd /tmp
opkg install /tmp/softcams-powercam-oscam_11715-emu-r798_all.ipk
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
sleep 1
rm -f /tmp/softcams-powercam-oscam_11715-emu-r798_all.ipk
sleep 2
exit
