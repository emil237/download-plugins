#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://raw.githubusercontent.com/emil237/plugins/main/EPG-PRO-grabber.tar.gz"
wait
tar -xzf EPG-PRO-grabber.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/EPG-PRO-grabber.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0



















