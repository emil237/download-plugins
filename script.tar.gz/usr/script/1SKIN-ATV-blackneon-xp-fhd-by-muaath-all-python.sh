#!/bin/sh
 # 
 # # 
cd /tmp
set -e 
wget "https://gitlab.com/emilnabil1/skins-atv-pli/-/raw/main/skins-blackneon-xp-fhd-by-muaath-all-python.tar.gz"
wait
tar -xzf skins-blackneon-xp-fhd-by-muaath-all-python.tar.gz  -C /
wait
cd ..
set +e
rm -f /tmp/skins-blackneon-xp-fhd-by-muaath-all-python.tar.gz
echo "   UPLOADED BY  >>>>   EMIL_NABIL "   
sleep 4;                                                                                                                  
echo "**********************************************************************************"
wait
exit 0



















