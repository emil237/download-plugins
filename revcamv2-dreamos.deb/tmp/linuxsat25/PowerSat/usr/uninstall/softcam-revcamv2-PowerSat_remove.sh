#!/bin/sh
dpkg -r enigma2-plugin-softcams-revcamv2-dm900-920
exit 0
