#!/bin/sh
########################################
######      Edited by LINUXSAT    ######
########################################
# Type: Ncam

/usr/script/revcamv2_cs.sh stop
sleep 5

rm -rf /usr/bin/Nrevcamv2
rm -rf /usr/script/revcamv2_cs.sh
rm -rf /usr/uninstall/revcamv2_remove.sh
rm -rf /lib/systemd/system/revcamv2.service
rm -rf /lib/systemd/system/revcamv2.socket

exit 0

