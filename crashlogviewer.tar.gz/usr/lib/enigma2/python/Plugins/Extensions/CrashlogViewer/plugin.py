#by 2boom 4bob@ua.fm 
from Screens.Screen import Screen
from Screens.PluginBrowser import PluginBrowser
from Screens.MessageBox import MessageBox
from Components.Sources.StaticText import StaticText
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Tools.LoadPixmap import LoadPixmap
from Screens.Console import Console
from Components.Label import Label
from Components.MenuList import MenuList
from Plugins.Plugin import PluginDescriptor
from Components.ScrollLabel import ScrollLabel
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, SCOPE_LANGUAGE
from os import environ, system, popen
import os, sys
import gettext
from enigma import getDesktop

global Crashfile 
Crashfile = " "

version = '0.4'

lang = language.getLanguage()
environ["LANGUAGE"] = lang[:2]
gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
gettext.textdomain("enigma2")
gettext.bindtextdomain("CrashlogViewer", "%s%s" % (resolveFilename(SCOPE_PLUGINS), "Extensions/CrashlogViewer/locale/"))

def _(txt):
	t = gettext.dgettext("CrashlogViewer", txt)
	if t == txt:
		t = gettext.gettext(txt)
	return t

class CrashLogScreen(Screen):
	sz_w = getDesktop(0).size().width()
	if sz_w == 1920:
		skin = """
		<screen name="crashlogscreen" position="480,100" size="960,880" title="View or Remove Crashlog files">
		<ePixmap position="10,868" zPosition="1" size="165,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/red.png" alphatest="blend" />
		<widget source="Redkey" render="Label" position="10,828" zPosition="2" size="165,30" font="Regular; 28" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<widget source="Greenkey" render="Label" position="220,828" zPosition="2" size="175,30" font="Regular; 28" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<ePixmap position="220,868" zPosition="1" size="175,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/green.png" alphatest="blend" />
		<ePixmap position="425,868" zPosition="1" size="165,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/yellow.png" transparent="1" alphatest="on" />
		<widget source="Yellowkey" render="Label" position="425,828" zPosition="2" size="165,30" valign="center" halign="center" font="Regular; 28" transparent="1" />
		<widget source="Bluekey" render="Label" position="635,828" zPosition="2" size="165,30" valign="center" halign="center" font="Regular; 28" transparent="1" />
		<ePixmap position="635,868" zPosition="1" size="165,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/blue.png" transparent="1" alphatest="on" />
		<ePixmap position="840,828" size="70,30" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/info.png" zPosition="2" alphatest="blend" />
		<widget source="menu" render="Listbox" position="20,10" size="920,781" scrollbarMode="showOnDemand">
		<convert type="TemplatedMultiContent">
		{"template": [
			MultiContentEntryText(pos = (70, 2), size = (580, 34), font=0, flags = RT_HALIGN_LEFT, text = 0), # index 2 is the Menu Titel
			MultiContentEntryText(pos = (80, 29), size = (580, 30), font=1, flags = RT_HALIGN_LEFT, text = 1), # index 3 is the Description
			MultiContentEntryPixmapAlphaTest(pos = (5, 15), size = (51, 40), png = 2), # index 4 is the pixmap
				],
		"fonts": [gFont("Regular", 30),gFont("Regular", 26)],
		"itemHeight": 71
		}
				</convert>
			</widget>
		</screen>"""
	else:
		skin = """
		<screen name="crashlogscreen" position="320,66" size="640,586" title="View or Remove Crashlog files">
		<ePixmap position="6,578" zPosition="1" size="110,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/red.png" alphatest="blend" />
		<widget source="Redkey" render="Label" position="6,552" zPosition="2" size="110,20" font="Regular; 18" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<widget source="Greenkey" render="Label" position="146,552" zPosition="2" size="116,20" font="Regular; 18" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<ePixmap position="146,578" zPosition="1" size="116,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/green.png" alphatest="blend" />
		<ePixmap position="283,578" zPosition="1" size="110,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/yellow.png" transparent="1" alphatest="on" />
		<widget source="Yellowkey" render="Label" position="283,552" zPosition="2" size="110,20" valign="center" halign="center" font="Regular; 18" transparent="1" />
		<widget source="Bluekey" render="Label" position="423,552" zPosition="2" size="110,20" valign="center" halign="center" font="Regular; 18" transparent="1" />
		<ePixmap position="423,578" zPosition="1" size="110,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/blue.png" transparent="1" alphatest="on" />
		<ePixmap position="560,552" size="46,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/info1.png" zPosition="2" alphatest="blend" />
		<widget source="menu" render="Listbox" position="13,6" size="613,517" scrollbarMode="showOnDemand">
		<convert type="TemplatedMultiContent">
		{"template": [
			MultiContentEntryText(pos = (46, 1), size = (386, 22), font=0, flags = RT_HALIGN_LEFT, text = 0), # index 2 is the Menu Titel
			MultiContentEntryText(pos = (53, 19), size = (386, 20), font=1, flags = RT_HALIGN_LEFT, text = 1), # index 3 is the Description
			MultiContentEntryPixmapAlphaTest(pos = (3, 10), size = (34, 26), png = 2), # index 4 is the pixmap
				],
		"fonts": [gFont("Regular", 18),gFont("Regular", 16)],
		"itemHeight": 47
		}
				</convert>
		</widget>
		</screen>"""

	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "EPGSelectActions"],
		{
			"ok": self.Ok,
			"cancel": self.exit,
			"back": self.exit,
			"red": self.exit,
			"green": self.Ok,
			"yellow": self.YellowKey,
			"blue": self.BlueKey,
			"info": self.infoKey,
			})
		self["Redkey"] = StaticText(_("Close"))
		self["Greenkey"] = StaticText(_("View"))
		self["Yellowkey"] = StaticText(_("Remove"))
		self["Bluekey"] = StaticText(_("Remove All"))
		self.list = []
		self["menu"] = List(self.list)
		self.CfgMenu()
		
	def CfgMenu(self):
		self.list = []
		crashfiles = os.popen("ls -lh /media/hdd/enigma2_crash*.log /home/root/logs/enigma2_crash*.log /tmp/twisted.log")
		sz_w = getDesktop(0).size().width()
		if sz_w == 1920:
			minipng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/CrashlogViewer/images/crashmini.png"))
		else:
			minipng = LoadPixmap(cached=True, path=resolveFilename(SCOPE_PLUGINS, "Extensions/CrashlogViewer/images/crashmini1.png"))
		for line in crashfiles:
			item = line.split(" ")
			name = item[-1].split("/")
			self.list.append((name[-1][:-5],("%s %s %s %s %s" % ( item[-7], item[-4], item[-5], item[-2], item[-3])), minipng, ("/%s/%s/" % (name[-3],name[-2]))))
		self["menu"].setList(self.list)
		self["actions"] = ActionMap(["OkCancelActions"], { "cancel": self.close}, -1)
		
	def Ok(self):
		item = self["menu"].getCurrent()
		global Crashfile
		try:
			if item[3] == '/root/logs/':
				Crashfile = '/home' + item[3] + item[0] + ".log"
			elif item[3] == '//tmp/':
				Crashfile = '/tmp/' + item[0] + ".log"
			else:
				Crashfile = item[3] + item[0] + ".log"
			
			self.session.openWithCallback(self.CfgMenu,LogScreen)
		except:
			Crashfile = " "
	
	def YellowKey(self):
		item = self["menu"].getCurrent()
		try:
			if item[3] == '/root/logs/':
				file = '/home' + item[3] + item[0] + ".log"
			elif item[3] == '//tmp/':
				file = '/tmp/' + item[0] + ".log"
			else:
				file = item[3] + item[0] + ".log"

			os.system("rm %s"%(file))
			self.mbox = self.session.open(MessageBox,(_("Removed %s") % (file)), MessageBox.TYPE_INFO, timeout = 4 )
		except:
			self.mbox = self.session.open(MessageBox,(_("Failed remove")), MessageBox.TYPE_INFO, timeout = 4 )
		self.CfgMenu()
		
	def BlueKey(self):
		try:
			os.system("rm /media/hdd/enigma2_crash*.log /home/root/logs/enigma2_crash*.log /tmp/twisted.log")
			self.mbox = self.session.open(MessageBox,(_("Removed All Crashlog Files") ), MessageBox.TYPE_INFO, timeout = 4 )
		except:
			self.mbox = self.session.open(MessageBox,(_("Failed remove")), MessageBox.TYPE_INFO, timeout = 4 )
		self.CfgMenu()
		
	def infoKey (self):
		self.session.open(MessageBox, _("Crashlog Viewer  ver. %s\n\nDeveloper: 2boom\n\nModifier: Evg77734\n\nHomepage: gisclub.tv") % version, MessageBox.TYPE_INFO)
		
	def exit(self):
		self.close()

class LogScreen(Screen):
	sz_w = getDesktop(0).size().width()
	if sz_w == 1920:
		skin = """
		<screen name="crashlogview" position="20,80" size="1880,980" title="View Crashlog file">
		<ePixmap position="1680,965" zPosition="1" size="170,2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/red.png" alphatest="blend" />
		<widget source="Redkey" render="Label" position="1680,920" zPosition="2" size="170,38" font="Regular; 28" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<widget name="text" position="10,10" size="1860,695" font="Console; 24" text="text" />
		<widget name="text2" position="10,720" size="1860,190" font="Console; 26" text="text2" foregroundColor="#ff0000" />
		<eLabel position="10,710" size="1860,2" backgroundColor="#555555" zPosition="1" />
		</screen>"""
	else:
		skin = """
		<screen name="crashlogview" position="13,53" size="1253,653" title="View Crashlog file">
		<ePixmap position="1120,643" zPosition="1" size="113,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/CrashlogViewer/images/red.png" alphatest="blend" />
		<widget source="Redkey" render="Label" position="1120,613" zPosition="2" size="113,25" font="Regular; 18" halign="center" valign="center" backgroundColor="background" foregroundColor="foreground" transparent="1" />
		<widget name="text" position="6,6" size="1240,463" font="Console; 16" text="text" />
		<widget name="text2" position="6,480" size="1240,126" font="Console; 17" text="text2" foregroundColor="#ff0000" />
		<eLabel position="6,473" size="1240,1" backgroundColor="#555555" zPosition="1" />
		</screen>"""

	def __init__(self, session):
		self.session = session
		Screen.__init__(self, session)
		global Crashfile
		self.setTitle('View Crashlog file:  ' + str(Crashfile))
		self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions"],
		{
			"cancel": self.exit,
			"back": self.exit,
			"red": self.exit,
			})
		self["Redkey"] = StaticText(_("Close"))
		self["Greenkey"] = StaticText(_("Restart GUI"))
		self["text"] = ScrollLabel("")
		self["text2"] = ScrollLabel("")
		self.list = []
		self["menu"] = List(self.list)
		self.listcrah()
		
	def exit(self):
		self.close()
		
	def listcrah(self):
		global Crashfile
		list = "No data error"
		list2 = "No data error"
		crashfiles = open(Crashfile, "r")
		for line in crashfiles:
			if line.find("Traceback (most recent call last):") != -1 or line.find("Backtrace:") != -1:
				list = " "
				list2 = " "
				for line in crashfiles:
					list += line
					if line.find("Error: ") != -1:
						list2 += line
					if line.find("]]>") != -1 or line.find("dmesg") != -1 or line.find("StackTrace") != -1 or line.find("FATAL SIGNAL") != -1:
						if line.find("FATAL SIGNAL") != -1:
							list2 = "FATAL SIGNAL"
						break
		self["text"].setText(list)
		crashfiles.close()
		self["text2"].setText(list2)
		
		self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], { "cancel": self.close, "up": self["text"].pageUp, "left": self["text"].pageUp, "down": self["text"].pageDown, "right": self["text"].pageDown,}, -1)

def main(session, **kwargs):
	session.open(CrashLogScreen)

def Plugins(**kwargs):
	return PluginDescriptor(
			name= (_("Crashlog  Viewer") + " ver. " + version),
			description= _("View and remove crashlog files"),
			where = [PluginDescriptor.WHERE_PLUGINMENU, PluginDescriptor.WHERE_EXTENSIONSMENU],
			icon="crash.png",
			fnc=main)

