#!/bin/sh
#DESCRIPTION=This script created by Levi45
###############################################################################
rm -R /usr/bin/btkcam
rm -R /usr/bin/cccam
rm -R /usr/bin/doscam
rm -R /usr/bin/gcam
rm -R /usr/bin/mgcamd
rm -R /usr/bin/multics
rm -R /usr/bin/multics64
rm -R /usr/bin/ncam
rm -R /usr/bin/ncam64
rm -R /usr/bin/oscampw
rm -R /usr/bin/oscampw64
rm -R /usr/bin/oscamtr
rm -R /usr/bin/oscamymod
rm -R /usr/bin/revcam
rm -R /usr/bin/scam
rm -R /usr/bin/suposcam
rm -R /usr/bin/tntoscam
rm -R /usr/bin/wicardd
rm -R /usr/camscript/*.sh

###############################################################################
echo "#########################################################"
echo "#                           Levi45                      #"
echo "#########################################################"
echo "#            All Emu's Deleted SUCCESSFULLY             #"
echo "#########################################################"
echo "#                    SATELLITE-FORUM.COM                #"
echo "#########################################################"
exit 0
