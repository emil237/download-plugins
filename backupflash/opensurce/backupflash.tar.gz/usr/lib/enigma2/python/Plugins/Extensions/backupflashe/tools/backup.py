#!/usr/bin/python
# -*- coding: utf-8 -*-
# RAED & mfaraj57 (c) 2015 - 2025

from Components.Label import Label
from Components.config import config
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from enigma import eTimer, getDesktop
from Components.ProgressBar import ProgressBar
from Components.Sources.StaticText import StaticText
from time import sleep
import os, datetime
import subprocess
import threading
import sys
import time

from .Console import Console
from .progress import ProgressScreen 
from .bftools import logdata, dellog, copylog, getboxtype

boxtype = getboxtype()

class BackupProgressScreen(Screen):
    def __init__(self, session, title="Backup in progress"):
        Screen.__init__(self, session)
        
        desktop = getDesktop(0)
        screen_width = desktop.size().width()
        
        if screen_width >= 1920:
            width = 800
            height = 250
            fontSize = 24
            button_width = 180
            button_height = 50
        else:
            width = 600
            height = 200
            fontSize = 18
            button_width = 150
            button_height = 40
        
        self.skin = """
        <screen position="center,center" size="%d,%d" title="%s">
            <widget name="info" position="10,10" size="%d,30" font="Regular;%d" halign="center" valign="center" />
            <widget name="progress" position="10,50" size="%d,30" borderWidth="2" />
            <widget name="percentage" position="10,90" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <widget name="status" position="10,120" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <widget name="time_info" position="10,150" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" zPosition="1" />
        </screen>
        """ % (
            width, height, title,
            width-20, fontSize,
            width-20,
            width-20, fontSize-4,
            width-20, fontSize-4,
            width-20, fontSize-4,
            (width//2)-button_width-10, height-button_height-10, button_width, button_height,
            (width//2)-button_width-10, height-button_height-10, button_width, button_height, fontSize-2
        )
        
        self["key_red"] = StaticText("Cancel")
        self["info"] = Label("Creating backup... Please wait.")
        self["progress"] = ProgressBar()
        self["percentage"] = Label("0%")
        self["status"] = Label("")
        self["time_info"] = Label("")
        
        self["progress"].setRange((0, 100))
        self["progress"].setValue(0)
        
        self["actions"] = ActionMap(["WizardActions", "ColorActions"], 
            {
                "back": self.cancelBackup,
                "red": self.cancelBackup,
                "cancel": self.cancelBackup,
                "exit": self.cancelBackup,
            }, -1)
        
        self.progress_value = 0
        self.last_progress = 0
        self.is_running = False
        self.progress_timer = eTimer()
        self.progress_timer.callback.append(self.updateProgress)
        
        self.start_time = 0
        self.backup_process = None
        self.output_lines = []
        
    def startBackup(self, cmd):
        self.start_time = time.time()
        self.is_running = True
        self.progress_value = 1
        self.last_progress = 0
        self.progress_timer.start(500)
        
        if isinstance(cmd, list):
            cmd_str = ' && '.join(cmd)
        else:
            cmd_str = str(cmd)
        
        self.backup_thread = threading.Thread(target=self.runBackup, args=(cmd_str,))
        self.backup_thread.daemon = True
        self.backup_thread.start()
    
    def runBackup(self, cmd_str):
        try:
            self.backup_process = subprocess.Popen(
                cmd_str, 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            for line in iter(self.backup_process.stdout.readline, ''):
                line = line.strip()
                if line:
                    self.output_lines.append(line)
                    
                    if "PROGRESS:" in line:
                        try:
                            percent_str = line.split("PROGRESS:")[1].strip().replace("%", "")
                            self.progress_value = int(percent_str.split("%")[0])
                        except:
                            pass
                    
                    if "BACKUP FINISHED IN" in line:
                        self.progress_value = 100
            
            self.backup_process.stdout.close()
            return_code = self.backup_process.wait()
            
        except Exception as e:
            return_code = 1
        
        self.cmdFinished(return_code)
    
    def updateProgress(self):
        if not self.is_running:
            return
        
        elapsed = time.time() - self.start_time
        
        if self.progress_value > self.last_progress:
            self.last_progress = self.progress_value
        
        if elapsed > 300:
            self.progress_value = min(99, self.progress_value + 1)
        
        if self.progress_value < 5 and elapsed > 10:
            self.progress_value = 5
        elif self.progress_value < 10 and elapsed > 20:
            self.progress_value = 10
        elif self.progress_value < 20 and elapsed > 30:
            self.progress_value = 20
        elif self.progress_value < 30 and elapsed > 60:
            self.progress_value = 30
        elif self.progress_value < 50 and elapsed > 120:
            self.progress_value = 50
        elif self.progress_value < 70 and elapsed > 180:
            self.progress_value = 70
        elif self.progress_value < 90 and elapsed > 240:
            self.progress_value = 90
        
        self["progress"].setValue(self.progress_value)
        self["percentage"].setText("%d%%" % self.progress_value)
        
        if self.progress_value < 20:
            self["status"].setText("Preparing backup...")
        elif self.progress_value < 40:
            self["status"].setText("Copying kernel...")
        elif self.progress_value < 60:
            self["status"].setText("Creating filesystem...")
        elif self.progress_value < 80:
            self["status"].setText("Compressing archive...")
        else:
            self["status"].setText("Finishing up...")
        
        if elapsed < 60:
            self["time_info"].setText("Starting...")
        else:
            remaining = max(0, 300 - elapsed)
            minutes = int(remaining / 60)
            seconds = int(remaining % 60)
            if remaining > 0:
                self["time_info"].setText("Estimated: %02d:%02d" % (minutes, seconds))
            else:
                self["time_info"].setText("Finishing...")
    
    def cmdFinished(self, retval):
        self.is_running = False
        self.progress_timer.stop()
        
        if retval == 0:
            self.progress_value = 100
            self["progress"].setValue(100)
            self["percentage"].setText("100%")
            self["info"].setText("Backup completed!")
            self["status"].setText("Success!")
            elapsed = int(time.time() - self.start_time)
            self["time_info"].setText("Completed in %d seconds" % elapsed)
        else:
            self["info"].setText("Backup failed!")
            self["status"].setText("Failed!")
            elapsed = int(time.time() - self.start_time)
            self["time_info"].setText("Failed after %d seconds" % elapsed)
        
        self.close_timer = eTimer()
        self.close_timer.callback.append(self.close)
        self.close_timer.start(3000, True)
    
    def cancelBackup(self):
        if self.is_running:
            self.is_running = False
            self.progress_timer.stop()
            
            try:
                with open("/tmp/.cancelBackup", "w") as f:
                    f.write("1")
            except:
                pass
            
            if self.backup_process:
                try:
                    self.backup_process.terminate()
                    time.sleep(1)
                    if self.backup_process.poll() is None:
                        self.backup_process.kill()
                    self.backup_process = None
                except:
                    pass
            
            os.system("pkill -f backup_script.sh 2>/dev/null")
            os.system("pkill -f tar 2>/dev/null")
            os.system("pkill -f bzip2 2>/dev/null")
            
            self["info"].setText("Backup cancelled!")
            self["status"].setText("Cancelled")
            self["time_info"].setText("")
            
            self.close()
        else:
            self.close()

BRANDOS = '/var/lib/dpkg/status'
BAINIT = '/sbin/bainit'
cancelBackup = "/tmp/.cancelBackup"
LOG = '/tmp/backupflash.scr'

def get_model_info():
    model = "unknown"
    brand = "ENIGMA"
    
    # التعرف على نوع الجهاز من خلال /etc/hostname أولاً
    if fileExists('/etc/hostname'):
        try:
            with open('/etc/hostname', 'r') as f:
                hostname = f.read().strip().lower()
                
                # تحليل hostname للتعرف على الموديل
                if 'vu' in hostname or 'solo' in hostname or 'uno' in hostname or 'ultimo' in hostname or 'duo' in hostname or 'zero' in hostname:
                    brand = "VU"
                    # استخراج الموديل من hostname
                    if 'solo4k' in hostname:
                        model = "solo4k"
                    elif 'uno4k' in hostname:
                        model = "uno4k"
                    elif 'ultimo4k' in hostname:
                        model = "ultimo4k"
                    elif 'duo4k' in hostname:
                        model = "duo4k"
                    elif 'zero4k' in hostname:
                        model = "zero4k"
                    else:
                        model = hostname
                elif 'dm' in hostname or 'dreambox' in hostname:
                    brand = "DREAMBOX"
                    if 'dm900' in hostname or 'dm920' in hostname:
                        model = hostname.replace('dm', 'dm')
                    else:
                        model = hostname
                elif 'gb' in hostname or 'gigablue' in hostname or 'quad' in hostname:
                    brand = "GIGABLUE"
                    if 'quad4k' in hostname:
                        model = "quad4k"
                    elif 'ue4k' in hostname:
                        model = "ue4k"
                    else:
                        model = hostname
                elif 'lunix' in hostname or 'qviart' in hostname:
                    brand = "QVIART"
                    if 'lunix3-4k' in hostname:
                        model = "lunix3-4k"
                    elif 'lunix4k' in hostname:
                        model = "lunix4k"
                    else:
                        model = hostname
                else:
                    # إذا لم نتعرف، نستخدم الاسم كما هو
                    brand = "ENIGMA"
                    model = hostname
        except:
            pass
    
    # إذا لم نتمكن من التعرف من hostname، نستخدم الملفات الأخرى
    if model == "unknown":
        info_files = [
            ('/proc/stb/info/vumodel', 'VU'),
            ('/proc/stb/info/hwmodel', 'QVIART'),
            ('/proc/stb/info/model', 'DREAMBOX'),
            ('/proc/stb/info/gbmodel', 'GIGABLUE'),
            ('/proc/stb/info/model_number', 'ENIGMA'),
            ('/proc/stb/info/boxtype', 'ENIGMA'),
            ('/proc/stb/info/brand', 'ENIGMA'),
            ('/etc/model', 'ENIGMA'),
            ('/proc/device-tree/model', 'ENIGMA'),
        ]
        
        for file_path, file_brand in info_files:
            if fileExists(file_path):
                try:
                    with open(file_path, 'r') as f:
                        model = f.read().strip()
                        brand = file_brand
                        break
                except:
                    pass
    
    return brand, model

def run_shell_backup(backup_dir):
    script_content = """#!/bin/sh

VERSION="Universal Enigma2 Backup Script\\n"
DIRECTORY="%s"
START=$(date +%%s)
DATE=`date +%%Y%%m%%d_%%H%%M`
IMAGEVERSION=`date +%%Y%%m%%d`
MKFS=/bin/tar
BZIP2=/usr/bin/bzip2
ROOTFSTYPE="rootfs.tar.bz2"
WORKDIR="$DIRECTORY/bi"

echo "PROGRESS: 5"
echo "Script date = $VERSION"
echo "Back-up media = $DIRECTORY"
df -h "$DIRECTORY"
echo "Back-up date_time = $DATE"
echo "Working directory = $WORKDIR"

# اكتشاف نوع الجهاز تلقائياً بدءاً من /etc/hostname
HOSTNAME=""
if [ -f /etc/hostname ]; then
    HOSTNAME=$(cat /etc/hostname | tr '[:upper:]' '[:lower:]')
    echo "Hostname detected: $HOSTNAME"
fi

# اكتشاف نوع الجهاز
if [ -f /proc/stb/info/vumodel ]; then
    MODEL=$(cat /proc/stb/info/vumodel)
    BRAND="VU"
    echo "Found VU+ model: $MODEL"
    
    # تحديد MTD_KERNEL بناءً على الموديل
    if [ "$MODEL" = "solo4k" ] || [ "$MODEL" = "uno4k" ] || [ "$MODEL" = "uno4kse" ] || [ "$MODEL" = "ultimo4k" ]; then
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="kernel_auto.bin"
    elif [ "$MODEL" = "zero4k" ]; then
        MTD_KERNEL="mmcblk0p4"
        KERNELNAME="kernel_auto.bin"
    elif [ "$MODEL" = "duo4k" ] || [ "$MODEL" = "duo4kse" ]; then
        MTD_KERNEL="mmcblk0p6"
        KERNELNAME="kernel_auto.bin"
    else
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="kernel_auto.bin"
    fi
    MAINDEST="$DIRECTORY/vuplus/$MODEL"
    BRAND_FOLDER="$DIRECTORY/vuplus"
    
elif [ -f /proc/stb/info/hwmodel ]; then
    MODEL=$(cat /proc/stb/info/hwmodel)
    BRAND="QVIART"
    echo "Found Qviart model: $MODEL"
    
    if [ "$MODEL" = "lunix3-4k" ] || [ "$MODEL" = "lunix4k" ]; then
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="oe_kernel.bin"
    else
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="oe_kernel.bin"
    fi
    MAINDEST="$DIRECTORY/update/$MODEL"
    BRAND_FOLDER="$DIRECTORY/update"
    
elif [ -f /proc/stb/info/model ]; then
    MODEL=$(cat /proc/stb/info/model)
    BRAND="DREAMBOX"
    echo "Found Dreambox model: $MODEL"
    
    if [ "$MODEL" = "dm900" ] || [ "$MODEL" = "dm920" ]; then
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="kernel.bin"
    else
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="kernel.bin"
    fi
    MAINDEST="$DIRECTORY/$MODEL"
    BRAND_FOLDER="$DIRECTORY"
    
elif [ -f /proc/stb/info/gbmodel ]; then
    MODEL=$(cat /proc/stb/info/gbmodel)
    BRAND="GIGABLUE"
    echo "Found Gigablue model: $MODEL"
    
    if [ "$MODEL" = "gbquad4k" ]; then
        MODEL="quad4k"
        MTDROOTFS=$(readlink /dev/root 2>/dev/null || echo "mmcblk0p3")
        if [ "$MTDROOTFS" = "mmcblk0p3" ]; then
            MTD_KERNEL="mmcblk0p2"
        elif [ "$MTDROOTFS" = "mmcblk0p5" ]; then
            MTD_KERNEL="mmcblk0p4"
        elif [ "$MTDROOTFS" = "mmcblk0p7" ]; then
            MTD_KERNEL="mmcblk0p6"
        elif [ "$MTDROOTFS" = "mmcblk0p9" ]; then
            MTD_KERNEL="mmcblk0p8"
        else
            MTD_KERNEL="mmcblk0p2"
        fi
        KERNELNAME="kernel.bin"
    elif [ "$MODEL" = "gbue4k" ]; then
        MODEL="ue4k"
        MTDROOTFS=$(readlink /dev/root 2>/dev/null || echo "mmcblk0p5")
        if [ "$MTDROOTFS" = "mmcblk0p5" ]; then
            MTD_KERNEL="mmcblk0p4"
        elif [ "$MTDROOTFS" = "mmcblk0p7" ]; then
            MTD_KERNEL="mmcblk0p6"
        elif [ "$MTDROOTFS" = "mmcblk0p9" ]; then
            MTD_KERNEL="mmcblk0p8"
        else
            MTD_KERNEL="mmcblk0p4"
        fi
        KERNELNAME="kernel.bin"
    else
        MTD_KERNEL="mmcblk0p1"
        KERNELNAME="kernel.bin"
    fi
    MAINDEST="$DIRECTORY/gigablue/$MODEL"
    BRAND_FOLDER="$DIRECTORY/gigablue"
    
elif [ -n "$HOSTNAME" ]; then
    # استخدام hostname للتعرف على الجهاز
    BRAND="ENIGMA"
    MODEL="$HOSTNAME"
    
    # محاولة تحديد العلامة التجارية من hostname
    case $HOSTNAME in
        *vu*|*solo*|*uno*|*ultimo*|*duo*|*zero*)
            BRAND="VU"
            MAINDEST="$DIRECTORY/vuplus/$MODEL"
            BRAND_FOLDER="$DIRECTORY/vuplus"
            ;;
        *dm*|*dreambox*)
            BRAND="DREAMBOX"
            MAINDEST="$DIRECTORY/$MODEL"
            BRAND_FOLDER="$DIRECTORY"
            ;;
        *gb*|*gigablue*|*quad*|*ue*)
            BRAND="GIGABLUE"
            MAINDEST="$DIRECTORY/gigablue/$MODEL"
            BRAND_FOLDER="$DIRECTORY/gigablue"
            ;;
        *lunix*|*qviart*)
            BRAND="QVIART"
            MAINDEST="$DIRECTORY/update/$MODEL"
            BRAND_FOLDER="$DIRECTORY/update"
            ;;
        *)
            BRAND="ENIGMA"
            MAINDEST="$DIRECTORY/enigma2/$MODEL"
            BRAND_FOLDER="$DIRECTORY/enigma2"
            ;;
    esac
    
    echo "Detected from hostname: Brand=$BRAND, Model=$MODEL"
    
    # تحديد MTD_KERNEL افتراضي
    MTD_KERNEL="mmcblk0p1"
    KERNELNAME="kernel.bin"
    
    # محاولة اكتشاف القسم المناسب
    for part in mmcblk0p1 mmcblk0p2 mmcblk0p3 mmcblk0p4 mmcblk0p5 mmcblk0p6 mmcblk0p7 mmcblk0p8 mmcblk0p9 mtd0 mtd1 mtd2 mtd3; do
        if [ -b "/dev/$part" ]; then
            if dd if=/dev/$part bs=1 count=4 2>/dev/null | grep -q "uImage"; then
                MTD_KERNEL=$part
                break
            fi
        fi
    done
    
else
    # لأي جهاز Enigma2 آخر
    BRAND="ENIGMA"
    MODEL="unknown"
    echo "Generic Enigma2 receiver"
    
    if [ -b "/dev/mmcblk0p1" ]; then
        MTD_KERNEL="mmcblk0p1"
    elif [ -b "/dev/mtd0" ]; then
        MTD_KERNEL="mtd0"
    else
        echo "Cannot detect storage type!"
        exit 1
    fi
    
    KERNELNAME="kernel.bin"
    MAINDEST="$DIRECTORY/enigma2/generic"
    BRAND_FOLDER="$DIRECTORY/enigma2"
fi

echo "PROGRESS: 10"
echo "Brand: $BRAND, Model: $MODEL"
echo "Kernel partition: /dev/$MTD_KERNEL"
echo "Destination: $MAINDEST"
echo "Brand folder: $BRAND_FOLDER"

if [ ! -f $MKFS ] ; then
    echo "NO TAR FOUND, ABORTING"
    exit 1
fi

if [ ! -f "$BZIP2" ] ; then
    echo "$BZIP2 not installed yet, now installing"
    opkg update > /dev/null 2>&1
    opkg install bzip2 > /dev/null 2>&1
    echo "Exit, try again"
    sleep 10
    exit 1
fi

echo "PROGRESS: 20"
echo "Starting Full Backup!"
echo "Options control panel will not be available 2-15 minutes."
echo "Please wait ..."
echo "--------------------------"

control_c(){
    echo "Control C was pressed, quitting..."
    umount /tmp/bi/root 2>/dev/null
    rmdir /tmp/bi/root 2>/dev/null
    rmdir /tmp/bi 2>/dev/null
    rm -rf "$WORKDIR" 2>/dev/null
    exit 255
}

trap control_c SIGINT

echo "WARNING!"
echo "To stop creating a backup, press the Menu button."
sleep 2

rm -rf "$WORKDIR"
echo "Remove directory   = $WORKDIR"
mkdir -p "$WORKDIR"
echo "Recreate directory = $WORKDIR"
mkdir -p /tmp/bi/root
echo "Create directory   = /tmp/bi/root"
sync
mount --bind / /tmp/bi/root

echo "PROGRESS: 40"
echo "Copying kernel from /dev/$MTD_KERNEL..."
dd if=/dev/$MTD_KERNEL of=$WORKDIR/$KERNELNAME bs=1M 2>/dev/null
sync

echo "PROGRESS: 60"
echo "Creating rootfs.tar..."
$MKFS -cf $WORKDIR/rootfs.tar -C /tmp/bi/root \\
    --exclude=/var/swap \\
    --exclude=/var/lib/opkg \\
    --exclude=/var/lib/dpkg \\
    --exclude=/var/nmbd/* \\
    --exclude=/tmp/* \\
    --exclude=/proc/* \\
    --exclude=/sys/* \\
    --exclude=/dev/* \\
    --exclude=/media/* \\
    --exclude=/mnt/* \\
    --exclude=/run/* \\
    --exclude=/home/* \\
    . 2>/dev/null

echo "PROGRESS: 80"
echo "Compressing archive..."
$BZIP2 $WORKDIR/rootfs.tar 2>/dev/null

echo "PROGRESS: 90"
echo "Moving files to destination..."
rm -rf "$MAINDEST"
mkdir -p "$MAINDEST"
mv "$WORKDIR/$KERNELNAME" "$MAINDEST/" 2>/dev/null
mv "$WORKDIR/$ROOTFSTYPE" "$MAINDEST/" 2>/dev/null

# إنشاء ملفات معلومات
echo "$MODEL-$IMAGEVERSION" > "$MAINDEST/imageversion"
echo "Backup created on $(date)" > "$MAINDEST/backup_info.txt"
echo "Brand: $BRAND" >> "$MAINDEST/backup_info.txt"
echo "Model: $MODEL" >> "$MAINDEST/backup_info.txt"
echo "Hostname: $HOSTNAME" >> "$MAINDEST/backup_info.txt"
echo "Kernel: $KERNELNAME" >> "$MAINDEST/backup_info.txt"
echo "Rootfs: rootfs.tar.bz2" >> "$MAINDEST/backup_info.txt"

# تنظيف
umount /tmp/bi/root 2>/dev/null || true
rmdir /tmp/bi/root 2>/dev/null || true
rmdir /tmp/bi 2>/dev/null || true
rm -rf "$WORKDIR"

echo "PROGRESS: 95"
if [ -f "$MAINDEST/rootfs.tar.bz2" -a -f "$MAINDEST/$KERNELNAME" ] ; then
    echo "BACKUP MADE SUCCESSFULLY IN: $MAINDEST"
    
    # ضغط المجلد الرئيسي بصيغة zip
    echo "Creating zip archive of brand folder..."
    if command -v zip >/dev/null 2>&1; then
        cd "$DIRECTORY"
        # الحصول على اسم المجلد الرئيسي فقط (آخر جزء من المسار)
        BRAND_FOLDER_NAME=$(basename "$BRAND_FOLDER")
        ZIP_NAME="backup_${BRAND_FOLDER_NAME}_${MODEL}_${DATE}.zip"
        
        echo "Creating zip file: $ZIP_NAME from folder: $BRAND_FOLDER_NAME"
        zip -r "$ZIP_NAME" "$BRAND_FOLDER_NAME" 2>/dev/null
        
        if [ -f "$DIRECTORY/$ZIP_NAME" ]; then
            ZIP_SIZE=$(du -h "$DIRECTORY/$ZIP_NAME" | cut -f1)
            echo "Zip archive created successfully: $ZIP_NAME ($ZIP_SIZE)"
        else
            echo "Failed to create zip archive"
        fi
    else
        echo "zip command not found, trying to install..."
        opkg update >/dev/null 2>&1
        opkg install zip >/dev/null 2>&1
        
        if command -v zip >/dev/null 2>&1; then
            cd "$DIRECTORY"
            BRAND_FOLDER_NAME=$(basename "$BRAND_FOLDER")
            ZIP_NAME="backup_${BRAND_FOLDER_NAME}_${MODEL}_${DATE}.zip"
            
            echo "Creating zip file: $ZIP_NAME from folder: $BRAND_FOLDER_NAME"
            zip -r "$ZIP_NAME" "$BRAND_FOLDER_NAME" 2>/dev/null
            
            if [ -f "$DIRECTORY/$ZIP_NAME" ]; then
                ZIP_SIZE=$(du -h "$DIRECTORY/$ZIP_NAME" | cut -f1)
                echo "Zip archive created successfully: $ZIP_NAME ($ZIP_SIZE)"
            else
                echo "Failed to create zip archive"
            fi
        else
            echo "Cannot install zip, skipping zip creation."
        fi
    fi
    
    echo "PROGRESS: 100"
    BACKUP_SUCCESS=1
else
    echo "Image creation FAILED!"
    BACKUP_SUCCESS=0
fi

sleep 2

END=$(date +%%s)
DIFF=$(( $END - $START ))
MINUTES=$(( $DIFF/60 ))
SECONDS=$(( $DIFF-(( 60*$MINUTES ))))
if [ $SECONDS -le  9 ] ; then
    SECONDS="0$SECONDS"
fi
echo "BACKUP FINISHED IN $MINUTES.$SECONDS MINUTES"

if [ $BACKUP_SUCCESS -eq 1 ]; then
    exit 0
else
    exit 1
fi
""" % backup_dir
    
    script_path = '/tmp/backup_script.sh'
    with open(script_path, 'w') as f:
        f.write(script_content)
    
    os.chmod(script_path, 0o755)
    
    cmd = 'sh %s' % script_path
    return cmd

class doBackUpInternal(Screen):
    def __init__(self, session, image_name=None, device_path=None, image_compression_value=0):
        Screen.__init__(self, session)
        
        desktop = getDesktop(0)
        screen_width = desktop.size().width()
        
        if screen_width >= 1920:
            width = 800
            height = 400
            fontSize = 24
            button_width = 180
            button_height = 50
        else:
            width = 600
            height = 300
            fontSize = 18
            button_width = 150
            button_height = 40
        
        red_pos = 10
        green_pos = width - button_width - 10
        
        self.skin = """
        <screen position="center,center" size="%d,%d" title="Backup Flash">
            <widget name="lab1" position="10,10" size="%d,%d" font="Regular;%d" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" zPosition="1" />
            <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#179416" foregroundColor="white" transparent="0" zPosition="1" />
        </screen>
        """ % (
            width, height,
            width-20, height-100, fontSize,
            red_pos, height-button_height-10, button_width, button_height,
            green_pos, height-button_height-10, button_width, button_height,
            red_pos, height-button_height-10, button_width, button_height, fontSize-2,
            green_pos, height-button_height-10, button_width, button_height, fontSize-2
        )
        
        self["key_red"] = StaticText("Cancel")
        self["key_green"] = StaticText("Backup")
        
        info_text = "Press GREEN to start backup\nPress RED to cancel\n\n"
        if device_path:
            info_text += "Backup will be saved to:\n%s" % device_path
        else:
            info_text += "No device selected"
        
        self["lab1"] = Label(info_text)
        
        self["actions"] = ActionMap(["ColorActions", "SetupActions"],
        {
            "red": self.close,
            "green": self.doBackUpjob,
            "cancel": self.close,
            "exit": self.close,
        })
        
        self.image_name = image_name
        self.device_path = device_path
        self.image_compression_value = image_compression_value
        self.session = session
        
    def doBackUpjob(self):
        if fileExists("/tmp/.cancelBackup"):
            os.system("rm -f /tmp/.cancelBackup")
        
        if not self.device_path:
            self.session.open(MessageBox,
                "No device selected for backup.",
                MessageBox.TYPE_ERROR)
            return
        
        logdata("Backup log", "start")
        NOW = datetime.datetime.now()
        logdata("Start Time", NOW.strftime('%H:%M'))
        
        script_cmd = run_shell_backup(self.device_path)
        
        cmdlist = [
            'echo "=== Starting Backup ==="',
            'date',
            script_cmd,
            'echo "=== Backup Finished ==="',
            'date'
        ]
        
        progress_screen = self.session.openWithCallback(self.dofinish, BackupProgressScreen, 
                                    title="Backup in Progress")
        
        full_cmd = ' && '.join(cmdlist)
        progress_screen.startBackup(full_cmd)
    
    def dofinish(self, ret=None):
        backup_success = False
        backup_file = ""
        kernel_file = ""
        backup_dir = ""
        zip_file = ""
        
        if self.device_path:
            box_type, model = get_model_info()
            
            # البحث عن ملفات الباكاب والملف المضغوط
            for root, dirs, files in os.walk(self.device_path):
                for file in files:
                    if file == 'rootfs.tar.bz2':
                        backup_file = os.path.join(root, file)
                        backup_dir = os.path.dirname(backup_file)
                    elif file.endswith(('.bin', '.auto', '.kernel')):
                        kernel_file = os.path.join(root, file)
                    elif file.endswith('.zip') and 'backup_' in file:
                        zip_file = os.path.join(root, file)
            
            if backup_file and kernel_file:
                backup_success = True
        
        NOW = datetime.datetime.now()
        logdata("Finish Time", NOW.strftime('%H:%M'))
        
        if fileExists("/tmp/.cancelBackup"):
            message = 'Backup was cancelled.'
            message_type = MessageBox.TYPE_WARNING
        elif backup_success:
            try:
                backup_size = os.path.getsize(backup_file) / (1024 * 1024)
                kernel_size = os.path.getsize(kernel_file) / 1024 if kernel_file else 0
                
                message = 'Backup completed successfully!\n\n'
                message += 'Files created:\n'
                message += '- rootfs.tar.bz2 (%.1f MB)\n' % backup_size
                if kernel_file:
                    message += '- %s (%.1f KB)\n' % (os.path.basename(kernel_file), kernel_size)
                
                # إضافة معلومات عن الملف المضغوط إذا كان موجوداً
                if zip_file and os.path.exists(zip_file):
                    zip_size = os.path.getsize(zip_file) / (1024 * 1024)
                    message += '- %s (%.1f MB)\n' % (os.path.basename(zip_file), zip_size)
                
                message += '\nLocation: %s' % backup_dir
            except:
                message = 'Backup completed successfully!\n\n'
                message += 'Files created:\n'
                message += '- rootfs.tar.bz2\n'
                if kernel_file:
                    message += '- %s\n' % os.path.basename(kernel_file)
                
                if zip_file and os.path.exists(zip_file):
                    message += '- %s\n' % os.path.basename(zip_file)
                
                message += '\nLocation: %s' % backup_dir
            message_type = MessageBox.TYPE_INFO
        else:
            message = 'Backup may have failed.\nCheck /tmp/backupflash.log for details.'
            message_type = MessageBox.TYPE_WARNING
        
        self.session.open(MessageBox, message, message_type)
        
        self.close()
