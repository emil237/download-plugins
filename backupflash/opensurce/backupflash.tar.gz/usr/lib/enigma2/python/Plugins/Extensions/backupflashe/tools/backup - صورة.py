#!/usr/bin/python
# -*- coding: utf-8 -*-
# RAED & mfaraj57 (c) 2015 - 2025

from Components.Label import Label
from Components.config import config
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from enigma import eTimer, getDesktop
from Components.ProgressBar import ProgressBar
from Components.Sources.StaticText import StaticText
from time import sleep
import os, datetime
import subprocess
import threading
import sys
import time

from .Console import Console
from .progress import ProgressScreen 
from .bftools import logdata, dellog, copylog, getboxtype

boxtype = getboxtype()

class BackupProgressScreen(Screen):
    def __init__(self, session, title="Backup in progress"):
        Screen.__init__(self, session)
        
        desktop = getDesktop(0)
        screen_width = desktop.size().width()
        
        if screen_width >= 1920:
            width = 800
            height = 250
            fontSize = 24
            button_width = 180
            button_height = 50
        else:
            width = 600
            height = 200
            fontSize = 18
            button_width = 150
            button_height = 40
        
        self.skin = """
        <screen position="center,center" size="%d,%d" title="%s">
            <widget name="info" position="10,10" size="%d,30" font="Regular;%d" halign="center" valign="center" />
            <widget name="progress" position="10,50" size="%d,30" borderWidth="2" />
            <widget name="percentage" position="10,90" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <widget name="status" position="10,120" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <widget name="time_info" position="10,150" size="%d,20" font="Regular;%d" halign="center" valign="center" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" zPosition="1" />
        </screen>
        """ % (
            width, height, title,
            width-20, fontSize,
            width-20,
            width-20, fontSize-4,
            width-20, fontSize-4,
            width-20, fontSize-4,
            (width//2)-button_width-10, height-button_height-10, button_width, button_height,
            (width//2)-button_width-10, height-button_height-10, button_width, button_height, fontSize-2
        )
        
        self["key_red"] = StaticText("Cancel")
        self["info"] = Label("Creating backup... Please wait.")
        self["progress"] = ProgressBar()
        self["percentage"] = Label("0%")
        self["status"] = Label("")
        self["time_info"] = Label("")
        
        self["progress"].setRange((0, 100))
        self["progress"].setValue(0)
        
        self["actions"] = ActionMap(["WizardActions", "ColorActions"], 
            {
                "back": self.cancelBackup,
                "red": self.cancelBackup,
                "cancel": self.cancelBackup,
                "exit": self.cancelBackup,
            }, -1)
        
        self.progress_value = 0
        self.last_progress = 0
        self.is_running = False
        self.progress_timer = eTimer()
        self.progress_timer.callback.append(self.updateProgress)
        
        self.start_time = 0
        self.backup_process = None
        self.output_lines = []
        
    def startBackup(self, cmd):
        self.start_time = time.time()
        self.is_running = True
        self.progress_value = 1
        self.last_progress = 0
        self.progress_timer.start(500)
        
        if isinstance(cmd, list):
            cmd_str = ' && '.join(cmd)
        else:
            cmd_str = str(cmd)
        
        self.backup_thread = threading.Thread(target=self.runBackup, args=(cmd_str,))
        self.backup_thread.daemon = True
        self.backup_thread.start()
    
    def runBackup(self, cmd_str):
        try:
            self.backup_process = subprocess.Popen(
                cmd_str, 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.STDOUT,
                universal_newlines=True,
                bufsize=1
            )
            
            for line in iter(self.backup_process.stdout.readline, ''):
                line = line.strip()
                if line:
                    self.output_lines.append(line)
                    
                    if "PROGRESS:" in line:
                        try:
                            percent_str = line.split("PROGRESS:")[1].strip().replace("%", "")
                            self.progress_value = int(percent_str.split("%")[0])
                        except:
                            pass
                    
                    if "BACK-UP MADE SUCCESSFULLY" in line:
                        self.progress_value = 100
            
            self.backup_process.stdout.close()
            return_code = self.backup_process.wait()
            
        except Exception as e:
            return_code = 1
        
        self.cmdFinished(return_code)
    
    def updateProgress(self):
        if not self.is_running:
            return
        
        elapsed = time.time() - self.start_time
        
        if self.progress_value > self.last_progress:
            self.last_progress = self.progress_value
        
        if elapsed > 300:
            self.progress_value = min(99, self.progress_value + 1)
        
        if self.progress_value < 5 and elapsed > 10:
            self.progress_value = 5
        elif self.progress_value < 10 and elapsed > 20:
            self.progress_value = 10
        elif self.progress_value < 20 and elapsed > 30:
            self.progress_value = 20
        elif self.progress_value < 30 and elapsed > 60:
            self.progress_value = 30
        elif self.progress_value < 50 and elapsed > 120:
            self.progress_value = 50
        elif self.progress_value < 70 and elapsed > 180:
            self.progress_value = 70
        elif self.progress_value < 90 and elapsed > 240:
            self.progress_value = 90
        
        self["progress"].setValue(self.progress_value)
        self["percentage"].setText("%d%%" % self.progress_value)
        
        if self.progress_value < 20:
            self["status"].setText("Preparing backup...")
        elif self.progress_value < 40:
            self["status"].setText("Copying kernel...")
        elif self.progress_value < 60:
            self["status"].setText("Creating filesystem...")
        elif self.progress_value < 80:
            self["status"].setText("Compressing archive...")
        else:
            self["status"].setText("Finishing up...")
        
        if elapsed < 60:
            self["time_info"].setText("Starting...")
        else:
            remaining = max(0, 300 - elapsed)
            minutes = int(remaining / 60)
            seconds = int(remaining % 60)
            if remaining > 0:
                self["time_info"].setText("Estimated: %02d:%02d" % (minutes, seconds))
            else:
                self["time_info"].setText("Finishing...")
    
    def cmdFinished(self, retval):
        self.is_running = False
        self.progress_timer.stop()
        
        if retval == 0:
            self.progress_value = 100
            self["progress"].setValue(100)
            self["percentage"].setText("100%")
            self["info"].setText("Backup completed!")
            self["status"].setText("Success!")
            elapsed = int(time.time() - self.start_time)
            self["time_info"].setText("Completed in %d seconds" % elapsed)
        else:
            self["info"].setText("Backup failed!")
            self["status"].setText("Failed!")
            elapsed = int(time.time() - self.start_time)
            self["time_info"].setText("Failed after %d seconds" % elapsed)
        
        self.close_timer = eTimer()
        self.close_timer.callback.append(self.close)
        self.close_timer.start(3000, True)
    
    def cancelBackup(self):
        if self.is_running:
            self.is_running = False
            self.progress_timer.stop()
            
            try:
                with open("/tmp/.cancelBackup", "w") as f:
                    f.write("1")
            except:
                pass
            
            if self.backup_process:
                try:
                    self.backup_process.terminate()
                    time.sleep(1)
                    if self.backup_process.poll() is None:
                        self.backup_process.kill()
                    self.backup_process = None
                except:
                    pass
            
            os.system("pkill -f backup_script.sh 2>/dev/null")
            os.system("pkill -f tar 2>/dev/null")
            os.system("pkill -f bzip2 2>/dev/null")
            
            self["info"].setText("Backup cancelled!")
            self["status"].setText("Cancelled")
            self["time_info"].setText("")
            
            self.close()
        else:
            self.close()

BRANDOS = '/var/lib/dpkg/status'
BAINIT = '/sbin/bainit'
cancelBackup = "/tmp/.cancelBackup"
LOG = '/tmp/backupflash.scr'

def get_model_info():
    if fileExists('/proc/stb/info/vumodel'):
        model = open('/proc/stb/info/vumodel').read().strip()
        if model in ['solo4k', 'uno4k', 'uno4kse', 'ultimo4k', 'zero4k', 'duo4k', 'duo4kse']:
            return 'VU', model
    elif fileExists('/proc/stb/info/hwmodel'):
        model = open('/proc/stb/info/hwmodel').read().strip()
        if model in ['lunix3-4k', 'lunix4k']:
            return 'QVIART', model
    elif fileExists('/proc/stb/info/model'):
        model = open('/proc/stb/info/model').read().strip()
        if model in ['dm900', 'dm920']:
            return 'DREAMBOX', model
    elif fileExists('/proc/stb/info/gbmodel'):
        model = open('/proc/stb/info/gbmodel').read().strip()
        if model == 'gbquad4k':
            return 'GIGABLUE', 'quad4k'
        elif model == 'gbue4k':
            return 'GIGABLUE', 'ue4k'
    return None, None

def run_shell_backup(backup_dir):
    script_content = """#!/bin/sh

VERSION="vu4k/dmm4k/gigablue4k/lunix4k models- 14/04/2019\\ncreator of the script Dimitrij (http://forums.openpli.org)\\n"
DIRECTORY="%s"
START=$(date +%%s)
DATE=`date +%%Y%%m%%d_%%H%%M`
IMAGEVERSION=`date +%%Y%%m%%d`
MKFS=/bin/tar
BZIP2=/usr/bin/bzip2
ROOTFSTYPE="rootfs.tar.bz2"
WORKDIR="$DIRECTORY/bi"

echo "PROGRESS: 5"
echo "Script date = $VERSION"
echo "Back-up media = $DIRECTORY"
df -h "$DIRECTORY"
echo "Back-up date_time = $DATE"
echo "Working directory = $WORKDIR"
echo -n "Drivers = "
opkg list-installed | grep dvb-proxy
opkg list-installed | grep dvb-modules
opkg list-installed | grep gigablue-platform-util

if [ -f /proc/stb/info/vumodel ] && [ ! -f /proc/stb/info/hwmodel ] && [ ! -f /proc/stb/info/gbmodel ] ; then
MODEL=$( cat /proc/stb/info/vumodel )
if [ $MODEL = "solo4k" ] ; then
echo "Found VU+ Solo 4K"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "uno4k" ] ; then
echo "Found VU+ Uno 4K"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "uno4kse" ] ; then
echo "Found VU+ Uno 4K se"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "ultimo4k" ] ; then
echo "Found VU+ Ultimo 4K"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "zero4k" ] ; then
echo "Found VU+ Zero 4K"
MTD_KERNEL="mmcblk0p4"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "duo4k" ] ; then
echo "Found VU+ Duo 4K"
MTD_KERNEL="mmcblk0p6"
KERNELNAME="kernel_auto.bin"
elif [ $MODEL = "duo4kse" ] ; then
echo "Found VU+ Duo 4K se"
MTD_KERNEL="mmcblk0p6"
KERNELNAME="kernel_auto.bin"
else
echo "No supported receiver found!"
exit 0
fi
TYPE=VU
SHOWNAME="Vu+ $MODEL"
MAINDEST="$DIRECTORY/vuplus/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE/vuplus"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
elif [ -f /proc/stb/info/hwmodel ] && [ ! -f /proc/stb/info/gbmodel ]; then
MODEL=$( cat /proc/stb/info/hwmodel )
if [ $MODEL = "lunix3-4k" ] ; then
echo "Found Qviart lunix3 4K"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="oe_kernel.bin"
TYPE=QVIART
SHOWNAME="Qviart $MODEL"
MAINDEST="$DIRECTORY/update/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE/update"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
elif [ $MODEL = "lunix4k" ] ; then
echo "Found Qviart lunix4K"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="oe_kernel.bin"
TYPE=QVIART
SHOWNAME="Qviart $MODEL"
MAINDEST="$DIRECTORY/update/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE/update"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
else
echo "No supported receiver found!"
exit 0
fi
elif [ -f /proc/stb/info/model ] && [ ! -f /proc/stb/info/hwmodel ] && [ ! -f /proc/stb/info/gbmodel ]; then
MODEL=$( cat /proc/stb/info/model )
if [ $MODEL = "dm900" ] || [ $MODEL = "dm920" ] ; then
echo "Found Dreambox dm900/dm920"
MTD_KERNEL="mmcblk0p1"
KERNELNAME="kernel.bin"
TYPE=DREAMBOX
SHOWNAME="Dreambox $MODEL"
MAINDEST="$DIRECTORY/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
else
echo "No supported receiver found!"
exit 0
fi
elif [ -f /proc/stb/info/gbmodel ] && [ ! -f /proc/stb/info/hwmodel ]; then
MODEL=$( cat /proc/stb/info/gbmodel )
if [ $MODEL = "gbquad4k" ] ; then
echo "Found GigaBlue UHD Quad 4K"
MODEL="quad4k"
MTDROOTFS=$(readlink /dev/root)
if [ $MTDROOTFS = "mmcblk0p3" ]; then
MTD_KERNEL="mmcblk0p2"
fi
if [ $MTDROOTFS = "mmcblk0p5" ]; then
MTD_KERNEL="mmcblk0p4"
fi
if [ $MTDROOTFS = "mmcblk0p7" ]; then
MTD_KERNEL="mmcblk0p6"
fi
if [ $MTDROOTFS = "mmcblk0p9" ]; then
MTD_KERNEL="mmcblk0p8"
fi
KERNELNAME="kernel.bin"
TYPE=GIGABLUE
SHOWNAME="Gigablue $MODEL"
MAINDEST="$DIRECTORY/gigablue/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE/gigablue"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
elif [ $MODEL = "gbue4k" ] ; then
echo "Found GigaBlue UHD UE 4K"
MODEL="ue4k"
MTDROOTFS=$(readlink /dev/root)
if [ $MTDROOTFS = "mmcblk0p5" ]; then
MTD_KERNEL="mmcblk0p4"
fi
if [ $MTDROOTFS = "mmcblk0p7" ]; then
MTD_KERNEL="mmcblk0p6"
fi
if [ $MTDROOTFS = "mmcblk0p9" ]; then
MTD_KERNEL="mmcblk0p8"
fi
KERNELNAME="kernel.bin"
TYPE=GIGABLUE
SHOWNAME="Gigablue $MODEL"
MAINDEST="$DIRECTORY/gigablue/$MODEL"
EXTRA="$DIRECTORY/automatic_fullbackup/$DATE/gigablue"
echo "Destination        = $MAINDEST"
echo "PROGRESS: 10"
else
echo "No supported receiver found!"
exit 0
fi
else
echo "No supported receiver found!"
exit 0
fi

if [ ! -f $MKFS ] ; then
echo "NO TAR FOUND, ABORTING"
exit 0
fi

if [ ! -f "$BZIP2" ] ; then
echo "$BZIP2 not installed yet, now installing"
opkg update > /dev/null 2>&1
opkg install bzip2 > /dev/null 2>&1
echo "Exit, try again"
sleep 10
exit 0
fi

echo "PROGRESS: 20"
echo "Starting Full Backup!"
echo "Options control panel will not be available 2-15 minutes."
echo "Please wait ..."
echo "--------------------------"

control_c(){
echo "Control C was pressed, quiting..."
umount /tmp/bi/root 2>/dev/null
rmdir /tmp/bi/root 2>/dev/null
rmdir /tmp/bi 2>/dev/null
rm -rf "$WORKDIR" 2>/dev/null
exit 255
}

trap control_c SIGINT

echo "WARNING!"
echo "To stop creating a backup, press the Menu button."
sleep 2

rm -rf "$WORKDIR"
echo "Remove directory   = $WORKDIR"
mkdir -p "$WORKDIR"
echo "Recreate directory = $WORKDIR"
mkdir -p /tmp/bi/root
echo "Create directory   = /tmp/bi/root"
sync
mount --bind / /tmp/bi/root

echo "PROGRESS: 40"
echo "Kernel resides on /dev/$MTD_KERNEL"
dd if=/dev/$MTD_KERNEL of=$WORKDIR/$KERNELNAME > /dev/null 2>&1

echo "PROGRESS: 60"
echo "Start creating rootfs.tar"
$MKFS -cf $WORKDIR/rootfs.tar -C /tmp/bi/root --exclude=/var/nmbd/* . > /dev/null 2>&1
echo "PROGRESS: 80"
$BZIP2 $WORKDIR/rootfs.tar > /dev/null 2>&1

TSTAMP="$(date "+%%Y-%%m-%%d-%%Hh%%Mm")"

if [ $TYPE = "VU" ] || [ $TYPE = "QVIART" ] || [ $TYPE = "DREAMBOX" ] || [ $TYPE = "GIGABLUE" ] ; then
rm -rf "$MAINDEST"
echo "Removed directory  = $MAINDEST"
mkdir -p "$MAINDEST"
echo "Created directory  = $MAINDEST"
mv "$WORKDIR/$KERNELNAME" "$MAINDEST/$KERNELNAME"
mv "$WORKDIR/$ROOTFSTYPE" "$MAINDEST/$ROOTFSTYPE"
echo "$MODEL-$IMAGEVERSION" > "$MAINDEST/imageversion"

if [ $MODEL = "lunix3-4k" ] || [ $MODEL = "lunix4k" ] || [ $MODEL = "dm900" ] || [ $MODEL = "dm920" ] ; then
echo ""
elif [ $MODEL = "uno4k" ] || [ $MODEL = "zero4k" ] ; then
echo "rename this file to 'force.update' when need confirmation" > "$MAINDEST/noforce.update"
else
if [ $TYPE != "GIGABLUE" ] ; then
echo "This file forces a reboot after the update" > "$MAINDEST/reboot.update"
fi
fi

if [ $MODEL = "zero4k" ] || [ $MODEL = "uno4k" ] || [ $MODEL = "uno4kse" ] || [ $MODEL = "ultimo4k" ] || [ $MODEL = "solo4k" ] || [ $MODEL = "duo4k" ] ; then
echo "rename this file to 'mkpart.update' for forces create partition and kernel update." > "$MAINDEST/nomkpart.update"
fi

if [ -f "$MAINDEST/rootfs.tar.bz2" -a -f "$MAINDEST/$KERNELNAME" ] ; then
echo " "
echo "BACK-UP MADE SUCCESSFULLY IN: $MAINDEST"
echo "PROGRESS: 100"
else
echo " "
echo "Image creation FAILED!"
exit 1
fi
fi

umount /tmp/bi/root
rmdir /tmp/bi/root
rmdir /tmp/bi
rm -rf "$WORKDIR"

sleep 5

END=$(date +%%s)
DIFF=$(( $END - $START ))
MINUTES=$(( $DIFF/60 ))
SECONDS=$(( $DIFF-(( 60*$MINUTES ))))
if [ $SECONDS -le  9 ] ; then
SECONDS="0$SECONDS"
fi
echo "BACKUP FINISHED IN $MINUTES.$SECONDS MINUTES"

echo "         EDIT SCRIPT BY EMIL NABIL "
sleep 4
exit 0
""" % backup_dir
    
    script_path = '/tmp/backup_script.sh'
    with open(script_path, 'w') as f:
        f.write(script_content)
    
    os.chmod(script_path, 0o755)
    
    cmd = 'sh %s' % script_path
    return cmd

class doBackUpInternal(Screen):
    def __init__(self, session, image_name=None, device_path=None, image_compression_value=0):
        Screen.__init__(self, session)
        
        desktop = getDesktop(0)
        screen_width = desktop.size().width()
        
        if screen_width >= 1920:
            width = 800
            height = 400
            fontSize = 24
            button_width = 180
            button_height = 50
        else:
            width = 600
            height = 300
            fontSize = 18
            button_width = 150
            button_height = 40
        
        red_pos = 10
        green_pos = width - button_width - 10
        
        self.skin = """
        <screen position="center,center" size="%d,%d" title="Backup Flash">
            <widget name="lab1" position="10,10" size="%d,%d" font="Regular;%d" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/red.png" transparent="1" alphatest="on" />
            <ePixmap position="%d,%d" size="%d,%d" pixmap="skin_default/buttons/green.png" transparent="1" alphatest="on" />
            <widget source="key_red" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#9f1313" foregroundColor="white" transparent="0" zPosition="1" />
            <widget source="key_green" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" backgroundColor="#179416" foregroundColor="white" transparent="0" zPosition="1" />
        </screen>
        """ % (
            width, height,
            width-20, height-100, fontSize,
            red_pos, height-button_height-10, button_width, button_height,
            green_pos, height-button_height-10, button_width, button_height,
            red_pos, height-button_height-10, button_width, button_height, fontSize-2,
            green_pos, height-button_height-10, button_width, button_height, fontSize-2
        )
        
        self["key_red"] = StaticText("Cancel")
        self["key_green"] = StaticText("Backup")
        
        info_text = "Press GREEN to start backup\nPress RED to cancel\n\n"
        if device_path:
            info_text += "Backup will be saved to:\n%s" % device_path
        else:
            info_text += "No device selected"
        
        self["lab1"] = Label(info_text)
        
        self["actions"] = ActionMap(["ColorActions", "SetupActions"],
        {
            "red": self.close,
            "green": self.doBackUpjob,
            "cancel": self.close,
            "exit": self.close,
        })
        
        self.image_name = image_name
        self.device_path = device_path
        self.image_compression_value = image_compression_value
        self.session = session
        
    def doBackUpjob(self):
        if fileExists("/tmp/.cancelBackup"):
            os.system("rm -f /tmp/.cancelBackup")
        
        if not self.device_path:
            self.session.open(MessageBox,
                "No device selected for backup.",
                MessageBox.TYPE_ERROR)
            return
        
        logdata("Backup log", "start")
        NOW = datetime.datetime.now()
        logdata("Start Time", NOW.strftime('%H:%M'))
        
        script_cmd = run_shell_backup(self.device_path)
        
        cmdlist = [
            'echo "=== Starting Backup ==="',
            'date',
            script_cmd,
            'echo "=== Backup Finished ==="',
            'date'
        ]
        
        progress_screen = self.session.openWithCallback(self.dofinish, BackupProgressScreen, 
                                    title="Backup in Progress")
        
        full_cmd = ' && '.join(cmdlist)
        progress_screen.startBackup(full_cmd)
    
    def dofinish(self, ret=None):
        backup_success = False
        backup_file = ""
        kernel_file = ""
        
        if self.device_path:
            box_type, model = get_model_info()
            if box_type and model:
                if box_type == 'DREAMBOX':
                    backup_dir = os.path.join(self.device_path, model)
                elif box_type == 'VU':
                    backup_dir = os.path.join(self.device_path, 'vuplus', model)
                elif box_type == 'GIGABLUE':
                    backup_dir = os.path.join(self.device_path, 'gigablue', model)
                elif box_type == 'QVIART':
                    backup_dir = os.path.join(self.device_path, 'update', model)
                else:
                    backup_dir = self.device_path
                
                if os.path.exists(backup_dir):
                    files_found = 0
                    for file in os.listdir(backup_dir):
                        if file == 'rootfs.tar.bz2':
                            backup_file = os.path.join(backup_dir, file)
                            files_found += 1
                        elif file.endswith('.bin'):
                            kernel_file = os.path.join(backup_dir, file)
                            files_found += 1
                    
                    if files_found >= 2:
                        backup_success = True
        
        NOW = datetime.datetime.now()
        logdata("Finish Time", NOW.strftime('%H:%M'))
        
        if fileExists("/tmp/.cancelBackup"):
            message = 'Backup was cancelled.'
            message_type = MessageBox.TYPE_WARNING
        elif backup_success:
            try:
                backup_size = os.path.getsize(backup_file) / (1024 * 1024)
                kernel_size = os.path.getsize(kernel_file) / 1024 if kernel_file else 0
                
                message = 'Backup completed successfully!\n\n'
                message += 'Files created:\n'
                message += '- rootfs.tar.bz2 (%.1f MB)\n' % backup_size
                if kernel_file:
                    message += '- %s (%.1f KB)\n' % (os.path.basename(kernel_file), kernel_size)
                message += '\nLocation: %s' % backup_dir
            except:
                message = 'Backup completed successfully!\n\n'
                message += 'Files created:\n'
                message += '- rootfs.tar.bz2\n'
                if kernel_file:
                    message += '- %s\n' % os.path.basename(kernel_file)
                message += '\nLocation: %s' % backup_dir
            message_type = MessageBox.TYPE_INFO
        else:
            message = 'Backup may have failed.\nCheck /tmp/backupflash.log for details.'
            message_type = MessageBox.TYPE_WARNING
        
        self.session.open(MessageBox, message, message_type)
        
        self.close()
