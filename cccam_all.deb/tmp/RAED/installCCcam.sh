#!/bin/sh
###################################
#Created By RAED 22-02-2021 Boxes #
###################################
FIN="=================================================="
#### Tmp work director 
TMPDIR='/tmp/RAED'
BINPATH='/tmp/RAED/CCcam239'
ARMBIN='/tmp/RAED/ARM/CCcam239'
MIPSBIN='/tmp/RAED/MIPS/CCcam239'
AARCH64BIN='/tmp/RAED/AARCH64/CCcam239'
#### Path of opkg files
STATUS='/var/lib/dpkg/status'
INFO='/var/lib/dpkg/info'
#### checking your device path
CHECK='/tmp/check'
### find image name type
GP3='/usr/lib/enigma2/python/Plugins/Bp/geminimain'
GP4='/usr/lib/enigma2/python/Plugins/GP4/geminilocale/plugin.pyo'
VTI='/usr/lib/enigma2/python/Plugins/SystemPlugins/VTIPanel'
TSIMAGE='/usr/lib/enigma2/python/Plugins/TSimage'
MERLIN='/usr/lib/enigma2/python/Plugins/Extensions/AddOnManager'
DreamElite1='/usr/lib/enigma2/python/DE'
DreamElite2='/usr/lib/enigma2/python/Plugins/DreamElite'
TDW='/usr/lib/enigma2/python/Plugins/Extensions/TDW'
NEWNIGMA2='/usr/lib/enigma2/python/Plugins/newnigma2'
SysCC='/usr/lib/enigma2/python/Plugins/Extensions/SysCC/plugin.pyo'
SATLODGE='/usr/lib/enigma2/python/Plugins/SatLodge'
PETERPAN='/usr/ppteam'
DreamOSat='/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatcamManager'
Demoni='/usr/lib/enigma2/python/Plugins/Extensions/Blue_Panel'
#### checking your device and bin file #####
uname -m > $CHECK
sleep 1;
if grep -qs -i 'armv7l' cat $CHECK ; then
   echo ':Your Device IS ARM processor ...'
   if [ ! -f $ARMBIN ] ; then
         echo "**************************"
         echo "**** Bin file Missing ****"
         echo "**************************"
         rm -r $TMPDIR > /dev/null 2>&1
         rm -r $CHECK > /dev/null 2>&1
         exit 1
   else
         cp -f $ARMBIN $TMPDIR
         if [ ! -f /usr/lib/libcrypt.so.1.1.0 ]; then # checking libcrypt
                  cp -f /tmp/RAED/ARM/libcrypt.so.1.1.0 /usr/lib
                  ln -sfn libcrypt.so.1.1.0 /usr/lib/libcrypt.so.1
         fi
   fi
#elif grep -qs -i 'aarch64' cat $CHECK ; then
#   echo ':Your Device IS AARCH64 processor ...'
#   if [ ! -f $AARCH64BIN ] ; then
#         echo "**************************"
#         echo "**** Bin file Missing ****"
#         echo "**************************"
#         rm -r $TMPDIR > /dev/null 2>&1
#         rm -r $CHECK > /dev/null 2>&1
#         exit 1
#   else
#         cp -f $AARCH64BIN $TMPDIR
#   fi
elif grep -qs -i 'mips' cat $CHECK ; then
   echo ':Your Device IS MIPS processor ...'
   if [ ! -f $MIPSBIN ] ; then
         echo "**************************"
         echo "**** Bin file Missing ****"
         echo "**************************"
         rm -r $TMPDIR > /dev/null 2>&1
         rm -r $CHECK > /dev/null 2>&1
         exit 1
   else
         cp -f $MIPSBIN $TMPDIR
         if [ ! -f /usr/lib/libcrypt.so.1.1.0 ]; then # checking libcrypt
                  cp -f /tmp/RAED/MIPS/libcrypt.so.1.1.0 /usr/lib
                  ln -sfn libcrypt.so.1.1.0 /usr/lib/libcrypt.so.1
         fi
   fi
else
   echo 'Sorry, your Device does not have the proper Emu'
   rm -r $TMPDIR > /dev/null 2>&1
   rm -r $CHECK > /dev/null 2>&1
   exit 1
fi
#########
if [ -r $DreamOSat ]; then
   echo "DreamOSat camManager"
   cp -rf $TMPDIR/DreamOSat/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
elif [ -e $GP3 ]; then
   echo "GP3 image"
   cp -rf $TMPDIR/GP3/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -f $GP4 ]; then
   echo "GP4 image"
   cp -rf $TMPDIR/GP4/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
else
if grep -qs -i "Power-Sat" /etc/issue; then
   echo "PowerSat image"
   cp -rf $TMPDIR/PowerSat/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif grep -qs -i "OoZooN" /etc/issue.net; then
   echo "OoZooN image"
   if [ ! -r /usr/camd ]; then
        mkdir -p /usr/camd > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/oozoon/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/camd/ > /dev/null 2>&1
elif [ -r $PETERPAN ]; then
   echo "PeterPan image"
   cp -rf $TMPDIR/PeterPan/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
   echo "0*CCcam_cam.pp* CCcam *" >>/usr/ppteam/.emulist
elif [ -r $VTI ]; then
   echo "VTI image"
   cp -rf $TMPDIR/vti/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $TSIMAGE ]; then
   echo "OpenTS/Ts image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/ts/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -r $NEWNIGMA2 ]; then
   echo "newnigma2 image"
   cp -rf $TMPDIR/newnigma2/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $MERLIN ]; then
   echo "Merlin4 image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/Merlin4/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -d $DreamElite1 -o -d $DreamElite2 ]; then
   echo "Dream-Elite image"
   if [ ! -d /var/bin ]; then
      ln -sfn /usr/bin /var/bin
   fi
   cp -rf $TMPDIR/dreamelite/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
   touch /etc/DExtra
   chmod -R 755 /etc/DExtra
elif [ -r $TDW ]; then
   echo "TDW image"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/TDW/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
elif [ -r $SATLODGE ]; then
   echo " Satlodge image"
   cp -rf $TMPDIR/satlodge/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/ > /dev/null 2>&1
elif [ -r $Demoni ]; then
   echo "DMS-Demoni image"
   cp -rf $TMPDIR/dddemon/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin > /dev/null 2>&1
elif [ -f $SysCC ]; then
   echo " SysCC Plugin"
   if [ ! -r /usr/bin/cam ]; then
        mkdir -p /usr/bin/cam > /dev/null 2>&1
   fi
   cp -rf $TMPDIR/SysCC/* / > /dev/null 2>&1
   cp -rf $BINPATH /usr/bin/cam/ > /dev/null 2>&1
else
rm -r $TMPDIR > /dev/null 2>&1
rm -r $CHECK > /dev/null 2>&1
echo "***************************************************"
echo "*                                                 *"
echo "* No emu script to this image now .. ask about it *"
echo "*                                                 *"
echo "***************************************************"
exit 1
fi
fi
######### checking link from /var/etc to /etc #########
if [ ! -L /var/etc ] ; then
   cp -rf /var/etc/* /etc
   rm -r /var/etc
   ln -sfn /etc /var
fi
######### checking config files #########
echo "";
if [ -f /etc/CCcam.cfg ]; then
   echo "[ Config CCcam Files found ]"
else
   echo "[ Config CCcam Files Not found ]"
   cp -rf /tmp/cccam/etc/* /etc > /dev/null 2>&1
fi
